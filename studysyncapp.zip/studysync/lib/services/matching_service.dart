import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/*
 * MatchingService implements the core matching algorithm for StudySync.
 * Handles course-based matching and preference compatibility scoring.
 * Manages connection requests and user relationships through Firebase.
 * Provides real-time updates for potential study partner matches.
 */

class MatchingService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<List<Map<String, dynamic>>> findPotentialMatches({
    required List<String> currentUserCourses,
  }) async {
    try {
      print("MatchingService: Starting findPotentialMatches");
      print("MatchingService: Current user courses: $currentUserCourses");

      final User? currentUser = _auth.currentUser;
      if (currentUser == null) throw Exception('User not authenticated');

      final userDoc =
          await _firestore.collection('users').doc(currentUser.uid).get();
      if (!userDoc.exists) throw Exception('User data not found');
      List<Map<String, dynamic>> matchedUsers = [];
      Set<String> sentRequestsIds = {};
      Set<String> connectedUserIds = {
        currentUser.uid,
      }; 

      try {
        final sentRequestsQuery =
            await _firestore
                .collection('connectionRequests')
                .where('fromUserId', isEqualTo: currentUser.uid)
                .where('status', isEqualTo: 'pending')
                .get();

        sentRequestsIds =
            sentRequestsQuery.docs
                .map((doc) => doc.data()['toUserId'] as String)
                .toSet();
      } catch (e) {
        print("Could not get connection requests due to permissions: $e");
      }

      try {
        final connectionsQuery =
            await _firestore
                .collection('connections')
                .where('users', arrayContains: currentUser.uid)
                .get();

        final userIdsFromConnections =
            connectionsQuery.docs.map((doc) {
              final users = List<String>.from(doc.data()['users']);
              return users.firstWhere((id) => id != currentUser.uid);
            }).toSet();

        connectedUserIds.addAll(userIdsFromConnections);
      } catch (e) {
        print("Could not get connections due to permissions: $e");
      }
      try {
        final allUsersQuery = await _firestore.collection('users').get();
        print(
          "MatchingService: Found ${allUsersQuery.docs.length} total users",
        );
        for (var doc in allUsersQuery.docs) {
          if (connectedUserIds.contains(doc.id)) {
            continue;
          }
          final Map<String, dynamic> userData = {};
          doc.data().forEach((key, value) {
            userData[key.toString()] = value;
          });

          List<String> otherUserCourses = [];
          if (userData.containsKey('courses') && userData['courses'] is List) {
            final List<dynamic> courses = userData['courses'];
            otherUserCourses = courses.map((c) => c.toString()).toList();
          }

          List<String> commonCourses =
              currentUserCourses
                  .where((course) => otherUserCourses.contains(course))
                  .toList();
          if (commonCourses.isEmpty) continue;
          Map<String, dynamic> userPreferences = {};
          if (userDoc.data() != null &&
              userDoc.data()!.containsKey('studyPreferences') &&
              userDoc.data()!['studyPreferences'] is Map) {
            final Map<dynamic, dynamic> rawPrefs =
                userDoc.data()!['studyPreferences'];
            rawPrefs.forEach((key, value) {
              userPreferences[key.toString()] = value;
            });
          }

          Map<String, dynamic> otherUserPreferences = {};
          if (userData.containsKey('studyPreferences') &&
              userData['studyPreferences'] is Map) {
            final Map<dynamic, dynamic> rawPrefs = userData['studyPreferences'];
            rawPrefs.forEach((key, value) {
              otherUserPreferences[key.toString()] = value;
            });
          }

          double compatibilityScore = _calculateCompatibilityScore(
            userPreferences,
            otherUserPreferences,
          );

          double courseMatchPercent =
              commonCourses.length / currentUserCourses.length * 100;
          double overallMatchPercent =
              (courseMatchPercent * 0.7) + (compatibilityScore * 0.3);
          bool requestSent = sentRequestsIds.contains(doc.id);
          matchedUsers.add({
            'uid': doc.id,
            'email': userData['email'] ?? 'No email',
            'name': userData['name'] ?? userData['email'] ?? 'Unknown user',
            'commonCourses': commonCourses,
            'matchPercentage': overallMatchPercent.round(),
            'compatibilityScore': compatibilityScore.round(),
            'profileImage': userData['profileImage'] ?? '',
            'bio': userData['bio'] ?? '',
            'requestSent': requestSent,
          });
        }
      } catch (e) {
        print("Error getting users: $e");
      }

      print("MatchingService: Returning ${matchedUsers.length} matches");
      return matchedUsers;
    } catch (e) {
      print('MatchingService error: $e');
      return [];
    }
  }

  double _calculateCompatibilityScore(
    Map<String, dynamic> prefs1,
    Map<String, dynamic> prefs2,
  ) {
    if (prefs1.isEmpty || prefs2.isEmpty) return 0;

    int total = 0;
    int matches = 0;
    Map<String, dynamic> safePrefs1 = {};
    prefs1.forEach((key, value) {
      safePrefs1[key.toString()] = value;
    });

    Map<String, dynamic> safePrefs2 = {};
    prefs2.forEach((key, value) {
      safePrefs2[key.toString()] = value;
    });

    for (var key in safePrefs1.keys) {
      if (safePrefs2.containsKey(key)) {
        total++;
        if (safePrefs1[key] == safePrefs2[key]) matches++;
      }
    }

    return total > 0 ? (matches / total) * 100 : 0;
  }

  Future<List<Map<String, dynamic>>> getIncomingRequests() async {
    try {
      final User? currentUser = _auth.currentUser;
      if (currentUser == null) throw Exception('User not authenticated');

      final requestsQuery =
          await _firestore
              .collection('connectionRequests')
              .where('toUserId', isEqualTo: currentUser.uid)
              .where('status', isEqualTo: 'pending')
              .get();

      return requestsQuery.docs
          .map((doc) => {...doc.data(), 'requestId': doc.id})
          .toList();
    } catch (e) {
      print('MatchingService.getIncomingRequests error: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> getUserConnections() async {
    try {
      final User? currentUser = _auth.currentUser;
      if (currentUser == null) throw Exception('User not authenticated');

      final connectionsQuery =
          await _firestore
              .collection('connections')
              .where('users', arrayContains: currentUser.uid)
              .get();

      List<Map<String, dynamic>> result = [];
      for (var doc in connectionsQuery.docs) {
        final connectionData = doc.data();
        final users = List<String>.from(connectionData['users']);
        final otherUserId = users.firstWhere((id) => id != currentUser.uid);
        try {
          final otherUserDoc =
              await _firestore.collection('users').doc(otherUserId).get();
          if (otherUserDoc.exists) {
            final otherUserData = otherUserDoc.data() ?? {};

            result.add({
              ...connectionData,
              'connectionId': doc.id,
              'otherUserId': otherUserId,
              'otherUserName':
                  otherUserData['name'] ??
                  otherUserData['email'] ??
                  'Unknown user',
              'otherUserEmail': otherUserData['email'] ?? '',
              'otherUserProfileImage': otherUserData['profileImage'] ?? '',
            });
          } else {
            result.add({
              ...connectionData,
              'connectionId': doc.id,
              'otherUserId': otherUserId,
              'otherUserName': 'Unknown user',
              'otherUserEmail': '',
            });
          }
        } catch (e) {
          print('Error fetching user data for $otherUserId: $e');
          result.add({
            ...connectionData,
            'connectionId': doc.id,
            'otherUserId': otherUserId,
            'otherUserName': 'User information unavailable',
            'otherUserEmail': '',
          });
        }
      }

      return result;
    } catch (e) {
      print('MatchingService.getUserConnections error: $e');
      return [];
    }
  }

  Future<void> sendConnectionRequest({
    required String receiverId,
    required String receiverName,
    required String receiverEmail,
  }) async {
    try {
      final User? currentUser = _auth.currentUser;
      if (currentUser == null) throw Exception('User not authenticated');

      await _firestore.collection('connectionRequests').add({
        'fromUserId': currentUser.uid,
        'fromUserName': currentUser.displayName ?? '',
        'fromUserEmail': currentUser.email ?? '',
        'toUserId': receiverId,
        'toUserName': receiverName,
        'toUserEmail': receiverEmail,
        'status': 'pending',
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('MatchingService.sendConnectionRequest error: $e');
    }
  }

  Future<bool> acceptConnectionRequest(String requestId) async {
    try {
      final requestDoc =
          await _firestore
              .collection('connectionRequests')
              .doc(requestId)
              .get();
      if (!requestDoc.exists) throw Exception('Request not found');
      final data = requestDoc.data()!;
      final fromUserId = data['fromUserId'];
      final toUserId = data['toUserId'];

      await _firestore.collection('connections').add({
        'users': [fromUserId, toUserId],
        'connectedAt': FieldValue.serverTimestamp(),
      });

      await _firestore.collection('connectionRequests').doc(requestId).update({
        'status': 'accepted',
      });

      return true;
    } catch (e) {
      print('MatchingService.acceptConnectionRequest error: $e');
      return false;
    }
  }

  Future<void> rejectConnectionRequest(String requestId) async {
    try {
      await _firestore.collection('connectionRequests').doc(requestId).update({
        'status': 'rejected',
      });
    } catch (e) {
      print('MatchingService.rejectConnectionRequest error: $e');
    }
  }
}
