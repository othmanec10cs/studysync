import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

/*
 * AuthService manages user authentication and profile management in StudySync.
 * Handles user sign-in, registration, password resets, and profile updates.
 * Integrates with Firebase Authentication for secure user management and
 * maintains user sessions. Implements retry logic for network operations
 * to ensure reliable authentication processes.
 */

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<User?> login(
    String email,
    String password, {
    int retryCount = 0,
  }) async {
    try {
      print(
        "AuthService: Attempting login with email: $email (attempt ${retryCount + 1})",
      );

      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      if (result.user != null) {
        print("AuthService: Login successful, updating last login timestamp");
        await _firestore
            .collection('users')
            .doc(result.user!.uid)
            .update({'lastLogin': FieldValue.serverTimestamp()})
            .catchError((e) {
              print("AuthService: Could not update last login: $e");
            });
      }

      return result.user;
    } on FirebaseAuthException catch (e) {
      print("AuthService: Login error: ${e.code} - ${e.message}");
      if ((e.code == 'network-request-failed' ||
              e.message?.contains('network') == true) &&
          retryCount < 2) {
        print("AuthService: Network error detected, retrying...");
        await Future.delayed(Duration(milliseconds: 800 * (retryCount + 1)));
        return login(email, password, retryCount: retryCount + 1);
      }
      rethrow;
    } catch (e) {
      print("AuthService: Unexpected login error: $e");
      throw Exception('Login failed: $e');
    }
  }

  Future<User?> register(
    String email,
    String password, {
    int retryCount = 0,
  }) async {
    try {
      print(
        "AuthService: Attempting registration with email: $email (attempt ${retryCount + 1})",
      );

      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      if (result.user != null) {
        print("AuthService: Registration successful, creating user document");
        await _firestore.collection('users').doc(result.user!.uid).set({
          'email': email,
          'createdAt': FieldValue.serverTimestamp(),
          'lastLogin': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }

      return result.user;
    } on FirebaseAuthException catch (e) {
      print("AuthService: Registration error: ${e.code} - ${e.message}");
      if ((e.code == 'network-request-failed' ||
              e.message?.contains('network') == true) &&
          retryCount < 2) {
        print("AuthService: Network error detected, retrying...");
        await Future.delayed(Duration(milliseconds: 800 * (retryCount + 1)));
        return register(email, password, retryCount: retryCount + 1);
      }
      rethrow;
    } catch (e) {
      print("AuthService: Unexpected registration error: $e");
      throw Exception('Registration failed: $e');
    }
  }

  Future<void> resetPassword(String email, {int retryCount = 0}) async {
    try {
      print(
        "AuthService: Sending password reset email to: $email (attempt ${retryCount + 1})",
      );

      await _auth.sendPasswordResetEmail(email: email);
    } on FirebaseAuthException catch (e) {
      print("AuthService: Reset password error: ${e.code} - ${e.message}");
      if ((e.code == 'network-request-failed' ||
              e.message?.contains('network') == true) &&
          retryCount < 2) {
        print("AuthService: Network error detected, retrying...");
        await Future.delayed(Duration(milliseconds: 800 * (retryCount + 1)));
        return resetPassword(email, retryCount: retryCount + 1);
      }
      rethrow;
    } catch (e) {
      print("AuthService: Unexpected reset password error: $e");
      throw Exception('Password reset failed: $e');
    }
  }

  Future<void> logout() async {
    try {
      print("AuthService: Signing out user");
      await _auth.signOut();
    } catch (e) {
      print("AuthService: Logout error: $e");
      throw Exception('Logout failed: $e');
    }
  }

  User? getCurrentUser() {
    return _auth.currentUser;
  }

  Future<void> updateUserProfile({
    String? displayName,
    String? photoURL,
  }) async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        if (displayName != null) {
          await user.updateDisplayName(displayName);
        }
        if (photoURL != null) {
          await user.updatePhotoURL(photoURL);
        }
      }
    } catch (e) {
      print("AuthService: Update profile error: $e");
      throw Exception('Profile update failed: $e');
    }
  }
}
