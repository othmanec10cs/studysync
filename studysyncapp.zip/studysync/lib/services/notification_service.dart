import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  
  // Local notification plugin
  final FlutterLocalNotificationsPlugin _localNotifications = 
      FlutterLocalNotificationsPlugin();
  
  // Initialize the service
  Future<void> initialize() async {
    // Request permission for notifications
    NotificationSettings settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );
    
    print('User granted notification permission: ${settings.authorizationStatus}');
    
    // Initialize local notifications
    const AndroidInitializationSettings androidSettings = 
        AndroidInitializationSettings('@mipmap/ic_launcher');
    
    const DarwinInitializationSettings iosSettings = 
        DarwinInitializationSettings(
          requestSoundPermission: true,
          requestBadgePermission: true,
          requestAlertPermission: true,
        );
    
    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );
    
    await _localNotifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        // Handle notification tap
        print('Notification tapped: ${response.payload}');
        // Add navigation logic here if needed
      },
    );
    
    // Handle background messages
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    
    // Handle foreground messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      _handleForegroundMessage(message);
    });
    
    // Save the FCM token to Firestore
    await _saveTokenToFirestore();
    
    // Listen for token refreshes
    _messaging.onTokenRefresh.listen(_saveTokenToDatabase);
  }
  
  // Save FCM token to user document
  Future<void> _saveTokenToFirestore() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;
      
      final token = await _messaging.getToken();
      if (token == null) return;
      
      await _saveTokenToDatabase(token);
    } catch (e) {
      print('Error saving FCM token: $e');
    }
  }
  
  Future<void> _saveTokenToDatabase(String token) async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;
      
      await _firestore.collection('users').doc(user.uid).update({
        'fcmToken': token,
        'lastTokenUpdate': FieldValue.serverTimestamp(),
      });
      
      print('FCM Token saved to database');
    } catch (e) {
      print('Error saving token to database: $e');
    }
  }
  
  // Background message handler
  static Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
    print('Handling background message: ${message.messageId}');
    // Cannot access instance members from static method
    // Background processing should be minimal
  }
  
  // Handle foreground messages
  void _handleForegroundMessage(RemoteMessage message) async {
    print('Got a message whilst in the foreground!');
    print('Message data: ${message.data}');
    
    if (message.notification != null) {
      print('Message also contained a notification: ${message.notification}');
      
      // Show local notification
      await _showLocalNotification(
        message.notification!.title ?? 'StudySync',
        message.notification!.body ?? 'You have a new notification',
        message.data,
      );
    }
  }
  
  // Show a local notification
  Future<void> _showLocalNotification(
    String title, 
    String body, 
    Map<String, dynamic> payload,
  ) async {
    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'study_sync_channel',
      'StudySync Notifications',
      channelDescription: 'Notifications for StudySync app',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,
    );
    
    const DarwinNotificationDetails iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );
    
    const NotificationDetails notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );
    
    await _localNotifications.show(
      0,  // Notification ID
      title,
      body,
      notificationDetails,
      payload: payload.toString(),
    );
  }
  
  // Get all notifications for the current user
  Stream<QuerySnapshot> getUserNotifications() {
    final user = _auth.currentUser;
    if (user == null) {
      throw Exception('User not authenticated');
    }
    
    return _firestore
        .collection('notifications')
        .where('userId', isEqualTo: user.uid)
        .orderBy('timestamp', descending: true)
        .snapshots();
  }
  
  // Get unread notification count
  Future<int> getUnreadNotificationCount() async {
    try {
      final user = _auth.currentUser;
      if (user == null) throw Exception('User not authenticated');
      
      final query = await _firestore
          .collection('notifications')
          .where('userId', isEqualTo: user.uid)
          .where('read', isEqualTo: false)
          .count()
          .get();
          
      return query.count ?? 0;
    } catch (e) {
      print('Error getting unread notification count: $e');
      return 0;
    }
  }
  
  // Mark notification as read
  Future<void> markNotificationAsRead(String notificationId) async {
    try {
      await _firestore
          .collection('notifications')
          .doc(notificationId)
          .update({'read': true});
    } catch (e) {
      print('Error marking notification as read: $e');
    }
  }
  
  // Mark all notifications as read
  Future<void> markAllNotificationsAsRead() async {
    try {
      final user = _auth.currentUser;
      if (user == null) throw Exception('User not authenticated');
      
      final batch = _firestore.batch();
      
      final querySnapshot = await _firestore
          .collection('notifications')
          .where('userId', isEqualTo: user.uid)
          .where('read', isEqualTo: false)
          .get();
          
      for (var doc in querySnapshot.docs) {
        batch.update(doc.reference, {'read': true});
      }
      
      await batch.commit();
    } catch (e) {
      print('Error marking all notifications as read: $e');
    }
  }
  
  // Delete a notification
  Future<void> deleteNotification(String notificationId) async {
    try {
      await _firestore
          .collection('notifications')
          .doc(notificationId)
          .delete();
    } catch (e) {
      print('Error deleting notification: $e');
    }
  }
  
  // Create local notification
  Future<void> createLocalNotification({
    required String title,
    required String body,
    Map<String, dynamic>? payload,
  }) async {
    await _showLocalNotification(
      title,
      body,
      payload ?? {},
    );
  }
}

// Notification list widget for displaying notifications
class NotificationListScreen extends StatefulWidget {
  const NotificationListScreen({super.key});

  @override
  State<NotificationListScreen> createState() => _NotificationListScreenState();
}

class _NotificationListScreenState extends State<NotificationListScreen> {
  final NotificationService _notificationService = NotificationService();
  bool _isLoading = false;
  
  @override
  void initState() {
    super.initState();
    _markAllAsRead();
  }
  
  Future<void> _markAllAsRead() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      await _notificationService.markAllNotificationsAsRead();
    } catch (e) {
      print('Error marking notifications as read: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : StreamBuilder<QuerySnapshot>(
              stream: _notificationService.getUserNotifications(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                
                if (snapshot.hasError) {
                  return Center(
                    child: Text('Error: ${snapshot.error}'),
                  );
                }
                
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.notifications_off, 
                             size: 64, 
                             color: Colors.grey.shade400),
                        const SizedBox(height: 16),
                        const Text(
                          'No notifications yet',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'When you receive notifications, they will appear here',
                          style: TextStyle(color: Colors.grey.shade600),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  );
                }
                
                final notifications = snapshot.data!.docs;
                
                return ListView.builder(
                  itemCount: notifications.length,
                  padding: const EdgeInsets.all(16),
                  itemBuilder: (context, index) {
                    final notification = notifications[index];
                    final data = notification.data() as Map<String, dynamic>;
                    
                    final String id = notification.id;
                    final String type = data['type'] ?? 'default';
                    final String message = data['message'] ?? 'New notification';
                    final Timestamp timestamp = data['timestamp'] ?? Timestamp.now();
                    final bool isRead = data['read'] ?? false;
                    
                    return Dismissible(
                      key: Key(id),
                      background: Container(
                        color: Colors.red,
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 16),
                        child: const Icon(
                          Icons.delete,
                          color: Colors.white,
                        ),
                      ),
                      direction: DismissDirection.endToStart,
                      onDismissed: (direction) {
                        _notificationService.deleteNotification(id);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Notification deleted'),
                          ),
                        );
                      },
                      child: Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ListTile(
                          leading: _getNotificationIcon(type, isRead),
                          title: Text(
                            message,
                            style: TextStyle(
                              fontWeight: isRead ? FontWeight.normal : FontWeight.bold,
                            ),
                          ),
                          subtitle: Text(
                            _formatTimestamp(timestamp),
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                          onTap: () {
                            _notificationService.markNotificationAsRead(id);
                            _handleNotificationTap(data);
                          },
                        ),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
  
  Widget _getNotificationIcon(String type, bool isRead) {
    IconData icon;
    Color color;
    
    switch (type) {
      case 'connection_request':
        icon = Icons.person_add;
        color = Colors.blue;
        break;
      case 'connection_accepted':
        icon = Icons.people;
        color = Colors.green;
        break;
      case 'study_session_invitation':
        icon = Icons.calendar_today;
        color = Colors.orange;
        break;
      case 'study_session_response':
        icon = Icons.event_available;
        color = Colors.deepPurple;
        break;
      case 'message':
        icon = Icons.message;
        color = Colors.indigo;
        break;
      default:
        icon = Icons.notifications;
        color = Colors.grey;
    }
    
    return CircleAvatar(
      backgroundColor: isRead ? color.withOpacity(0.2) : color.withOpacity(0.8),
      child: Icon(
        icon,
        color: isRead ? color.withOpacity(0.5) : Colors.white,
      ),
    );
  }
  
  String _formatTimestamp(Timestamp timestamp) {
    final now = DateTime.now();
    final dateTime = timestamp.toDate();
    final difference = now.difference(dateTime);
    
    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inHours < 1) {
      final minutes = difference.inMinutes;
      return '$minutes ${minutes == 1 ? 'minute' : 'minutes'} ago';
    } else if (difference.inDays < 1) {
      final hours = difference.inHours;
      return '$hours ${hours == 1 ? 'hour' : 'hours'} ago';
    } else if (difference.inDays < 7) {
      final days = difference.inDays;
      return '$days ${days == 1 ? 'day' : 'days'} ago';
    } else {
      return '${dateTime.month}/${dateTime.day}/${dateTime.year}';
    }
  }
  
  void _handleNotificationTap(Map<String, dynamic> data) {
    final type = data['type'] ?? 'default';
    
    switch (type) {
      case 'connection_request':
        Navigator.pushReplacementNamed(context, '/matches');
        break;
      case 'connection_accepted':
        Navigator.pushReplacementNamed(context, '/matches');
        break;
      case 'study_session_invitation':
      case 'study_session_response':
        if (data['senderId'] != null) {
          // Navigate to study session screen with partner
        }
        break;
      case 'message':
        if (data['senderId'] != null && data['senderName'] != null) {
          final senderId = data['senderId'];
          final senderName = data['senderName'];
          final senderEmail = data['senderEmail'] ?? '';
          
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => ChatScreen(
                receiverId: senderId,
                receiverName: senderName,
                receiverEmail: senderEmail,
              ),
            ),
          );
        }
        break;
      default:
        // Do nothing
    }
  }
}

// Widget to display notification badge
class NotificationBadge extends StatelessWidget {
  final NotificationService _notificationService = NotificationService();
  
  NotificationBadge({super.key});
  
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: _notificationService.getUserNotifications(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const SizedBox.shrink();
        }
        
        final notifications = snapshot.data!.docs;
        final unreadCount = notifications.where((doc) {
          final data = doc.data() as Map<String, dynamic>;
          return data['read'] == false;
        }).length;
        
        if (unreadCount == 0) {
          return const Icon(Icons.notifications_none);
        }
        
        return Badge(
          label: Text(unreadCount.toString()),
          child: const Icon(Icons.notifications),
        );
      },
    );
  }
}

// Add this class reference for the ChatScreen
class ChatScreen extends StatefulWidget {
  final String receiverId;
  final String receiverName;
  final String receiverEmail;

  const ChatScreen({
    super.key,
    required this.receiverId,
    required this.receiverName,
    required this.receiverEmail,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  @override
  Widget build(BuildContext context) {
    // This is just a placeholder to make the code compile
    // The actual ChatScreen will be imported from your existing code
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.receiverName),
      ),
      body: const Center(
        child: Text('Chat screen'),
      ),
    );
  }
}