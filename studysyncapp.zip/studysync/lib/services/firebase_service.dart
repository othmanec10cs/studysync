import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/*
 * FirebaseService manages the core Firebase integration for StudySync.
 * Handles app initialization, connection management, and service health checks.
 * Implements retry logic for initialization failures and monitors
 * connectivity status. Provides methods to verify Firebase service
 * availability and connection state.
 */

class FirebaseService {
  static bool _isInitialized = false;
  static int _initAttempts = 0;
  static const int maxInitAttempts = 3;

  static Future<bool> initializeFirebase() async {
    if (_isInitialized) return true;

    _initAttempts++;
    print("🔥 Firebase initialization attempt $_initAttempts");

    try {
      if (Firebase.apps.isNotEmpty) {
        _isInitialized = true;
        return true;
      }

      await Firebase.initializeApp(
        options: const FirebaseOptions(
          apiKey: "AIzaSyBkdQACP2fm8oJdZIvLi_AhAu8Xt-NtKfc",
          authDomain: "studysync-f1639.firebaseapp.com",
          projectId: "studysync-f1639",
          storageBucket: "studysync-f1639.appspot.com",
          messagingSenderId: "451077567042",
          appId: "1:451077567042:web:a3b3dd9d922077447b73db",
        ),
      );

      _isInitialized = true;
      print("✅ Firebase initialized successfully");
      return true;
    } catch (e) {
      print("❌ Firebase initialization error: $e");

      if (_initAttempts < maxInitAttempts) {
        final delay = Duration(
          milliseconds: 500 * (_initAttempts * _initAttempts),
        );
        await Future.delayed(delay);
        return await initializeFirebase(); 
        }

      return false;
    }
  }

  static Future<bool> testConnectivity({Duration? timeout}) async {
    timeout ??= const Duration(seconds: 3);

    try {
      try {
        final authStream = FirebaseAuth.instance.authStateChanges();
        await authStream.first.timeout(timeout);
        print("✅ Firebase Auth connectivity test successful");
        return true;
      } catch (e) {
        print("⚠️ Firebase Auth connectivity test failed: $e");
      }

      try {
        final firestoreQuery = FirebaseFirestore.instance
            .collection('users')
            .limit(1);
        await firestoreQuery.get().timeout(timeout);
        print("✅ Firebase Firestore connectivity test successful");
        return true;
      } catch (e) {
        print("⚠️ Firebase Firestore connectivity test failed: $e");
      }

      return false;
    } catch (e) {
      print("❌ Firebase connectivity test completely failed: $e");
      return false;
    }
  }

  static Future<bool> checkFirebaseConnection() async {
    final isInitialized = await initializeFirebase();
    if (!isInitialized) return false;

    await Future.delayed(const Duration(milliseconds: 500));

    return await testConnectivity();
  }

  static Future<bool> pingFirebase() async {
    try {
      if (Firebase.apps.isEmpty) {
        return false;
      }

      final FirebaseApp app = Firebase.app();
      final options = app.options;
      final projectId = options.projectId;

      return projectId.isNotEmpty;
    } catch (e) {
      print("❌ Firebase ping failed: $e");
      return false;
    }
  }
}
