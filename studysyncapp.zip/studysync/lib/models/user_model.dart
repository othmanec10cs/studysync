class UserModel {
  final String uid;
  final List<String> courses;

  UserModel({required this.uid, required this.courses});

  factory UserModel.fromFirestore(String uid, Map<String, dynamic> data) {
    return UserModel(
      uid: uid,
      courses: List<String>.from(data['courses'] ?? []),
    );
  }
}
