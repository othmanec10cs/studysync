/*
 * StudySessionSchedulingScreen manages the creation and scheduling of study sessions.
 * Provides calendar interface for selecting session times and duration.
 * Handles session invitations, participant management, and scheduling
 * conflicts. Integrates with Firebase for real-time session updates.
 */

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class StudySessionSchedulingScreen extends StatefulWidget {
  const StudySessionSchedulingScreen({Key? key}) : super(key: key);

  @override
  State<StudySessionSchedulingScreen> createState() =>
      _StudySessionSchedulingScreenState();
}

class _StudySessionSchedulingScreenState
    extends State<StudySessionSchedulingScreen>
    with TickerProviderStateMixin {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  late AnimationController _animationController;

  late TabController _tabController;

  final _formKey = GlobalKey<FormState>();
  List<String> userCourses = [];
  List<Map<String, dynamic>> studyPartners = [];
  Map<String, List<String>> _partnerCommonCourses = {};
  String? _selectedCourse;
  String? _selectedPartnerId;
  String? _selectedPartnerName;
  DateTime _selectedDate = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _selectedTime = const TimeOfDay(hour: 14, minute: 0);
  String _selectedLocation = 'Library';
  int _selectedDuration = 60;
  String _sessionNotes = '';

  bool _isLoading = true;
  bool _isSaving = false;
  bool _hasError = false;
  String _errorMessage = '';

  List<Map<String, dynamic>> _upcomingSessions = [];
  List<Map<String, dynamic>> _pendingSessions = [];

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _tabController = TabController(length: 3, vsync: this);

    _loadData().then((_) {
      if (mounted) {
        _animationController.forward();
      }
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });

    try {

      final user = _auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final userDoc = await _firestore.collection('users').doc(user.uid).get();
      final userData = userDoc.data();

      if (userData != null) {
        userCourses = List<String>.from(userData['courses'] ?? []);
      }
      await _loadStudyPartners();
      await _loadSessions();

      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _hasError = true;
        _errorMessage = 'Failed to load user data: $e';
      });
    }
  }

  Future<void> _loadStudyPartners() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;
      final connectionsQuery =
          await _firestore
              .collection('connections')
              .where('users', arrayContains: user.uid)
              .get();

      final List<Map<String, dynamic>> partners = [];
      final Map<String, List<String>> partnerCommonCourses = {};
      for (var connection in connectionsQuery.docs) {
        final List<String> users = List<String>.from(
          connection.data()['users'] ?? [],
        );
        final String partnerId = users.firstWhere(
          (id) => id != user.uid,
          orElse: () => '',
        );

        if (partnerId.isNotEmpty) {
          final partnerDoc =
              await _firestore.collection('users').doc(partnerId).get();
          if (partnerDoc.exists) {
            final partnerData = partnerDoc.data() ?? {};

            final List<String> partnerCourses = List<String>.from(
              partnerData['courses'] ?? [],
            );
            final List<String> commonCourses =
                userCourses
                    .where((course) => partnerCourses.contains(course))
                    .toList();

            if (commonCourses.isNotEmpty) {
              partners.add({
                'id': partnerId,
                'name': partnerData['name'] ?? 'Unknown',
                'email': partnerData['email'] ?? '',
                'commonCourses': commonCourses,
              });
              partnerCommonCourses[partnerId] = commonCourses;
            }
          }
        }
      }

      setState(() {

        final seen = <String>{};
        studyPartners =
            partners.where((partner) => seen.add(partner['id'])).toList();
        _partnerCommonCourses = partnerCommonCourses;
        if (studyPartners.isNotEmpty) {
          _selectedPartnerId = studyPartners.first['id'];
          _selectedPartnerName = studyPartners.first['name'];
          if (_partnerCommonCourses.containsKey(_selectedPartnerId)) {
            final commonCourses = _partnerCommonCourses[_selectedPartnerId]!;
            if (commonCourses.isNotEmpty) {
              _selectedCourse = commonCourses.first;
            }
          }
        }
      });
    } catch (e) {
      print('Error loading study partners: $e');

    }
  }

  Future<void> _loadSessions() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;
      final sessionsQuery =
          await _firestore
              .collection('studySessions')
              .where('participants', arrayContains: user.uid)
              .orderBy('dateTime')
              .get();

      final List<Map<String, dynamic>> upcoming = [];
      final List<Map<String, dynamic>> past = [];
      final List<Map<String, dynamic>> pending = [];

      final now = DateTime.now();

      for (var session in sessionsQuery.docs) {
        final sessionData = session.data();
        final List<String> participants = List<String>.from(
          sessionData['participants'] ?? [],
        );

        final String partnerId = participants.firstWhere(
          (id) => id != user.uid,
          orElse: () => '',
        );

        String partnerName = 'Unknown';
        if (partnerId.isNotEmpty) {
          try {
            final partnerDoc =
                await _firestore.collection('users').doc(partnerId).get();
            if (partnerDoc.exists) {
              partnerName = partnerDoc.data()?['name'] ?? 'Unknown';
            }
          } catch (e) {
          }
        }

        final sessionDateTime = (sessionData['dateTime'] as Timestamp).toDate();
        final sessionStatus = sessionData['status'] as String? ?? 'scheduled';
        final createdBy = sessionData['createdBy'] as String? ?? '';

        final sessionObject = {
          'id': session.id,
          'course': sessionData['course'] ?? 'Not specified',
          'dateTime': sessionDateTime,
          'location': sessionData['location'] ?? 'Not specified',
          'duration': sessionData['durationMinutes'] ?? 60,
          'notes': sessionData['notes'] ?? '',
          'status': sessionStatus,
          'partnerId': partnerId,
          'partnerName': partnerName,
          'createdBy': createdBy,
          'isCreator': createdBy == user.uid,
          'responses': sessionData['responses'] ?? {},
        };
        if (sessionStatus == 'cancelled') {
          continue;
        } else if (sessionStatus == 'pending' && createdBy != user.uid) {
          pending.add(sessionObject);
        } else if (sessionDateTime.isAfter(now)) {
          if (sessionStatus == 'scheduled' || sessionStatus == 'pending') {
            upcoming.add(sessionObject);
          }
        } else {
          past.add(sessionObject);
        }
      }

      setState(() {
        _upcomingSessions = upcoming;
        _pendingSessions = pending;
      });
    } catch (e) {
      print('Error loading sessions: $e');
    }
  }

  Future<void> _scheduleSession() async {
    if (_formKey.currentState == null || !_formKey.currentState!.validate()) {
      return;
    }
    if (_selectedCourse == null || _selectedCourse!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select a course'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (_selectedPartnerId == null || _selectedPartnerId!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select a study partner'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      _isSaving = true;
    });

    try {
      final user = _auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final sessionDateTime = DateTime(
        _selectedDate.year,
        _selectedDate.month,
        _selectedDate.day,
        _selectedTime.hour,
        _selectedTime.minute,
      );
      final sessionRef = await _firestore.collection('studySessions').add({
        'course': _selectedCourse,
        'dateTime': Timestamp.fromDate(sessionDateTime),
        'location': _selectedLocation,
        'durationMinutes': _selectedDuration,
        'notes': _sessionNotes,
        'status': 'scheduled',
        'createdBy': user.uid,
        'createdAt': FieldValue.serverTimestamp(),
        'participants': [user.uid, _selectedPartnerId],
        'responses': {user.uid: 'confirmed'},
      });

      await _firestore.collection('notifications').add({
        'userId': _selectedPartnerId,
        'type': 'study_session_invitation',
        'senderId': user.uid,
        'senderName': user.displayName ?? user.email,
        'message':
            '${user.displayName ?? 'Your study partner'} invited you to study $_selectedCourse',
        'timestamp': FieldValue.serverTimestamp(),
        'read': false,
        'sessionInfo': {
          'sessionId': sessionRef.id,
          'course': _selectedCourse,
          'dateTime': Timestamp.fromDate(sessionDateTime),
          'location': _selectedLocation,
        },
      });
      _resetForm();
      await _loadSessions();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Study session scheduled with $_selectedPartnerName'),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to schedule session: $e'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      );
    } finally {
      setState(() {
        _isSaving = false;
      });
    }
  }

  Future<void> _respondToSession(String sessionId, bool accept) async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;

      final sessionRef = _firestore.collection('studySessions').doc(sessionId);

      if (accept) {

        await sessionRef.update({
          'status': 'scheduled',
          'responses.${user.uid}': 'confirmed',
          'updatedAt': FieldValue.serverTimestamp(),
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Study session accepted'),
            backgroundColor: Colors.green,
          ),
        );
      } else {

        await sessionRef.update({
          'status': 'cancelled',
          'responses.${user.uid}': 'declined',
          'updatedAt': FieldValue.serverTimestamp(),
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Study session declined'),
            backgroundColor: Colors.orange,
          ),
        );
      }
      await _loadSessions();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to respond to session: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _cancelSession(String sessionId) async {
    try {
      await _firestore.collection('studySessions').doc(sessionId).update({
        'status': 'cancelled',
        'updatedAt': FieldValue.serverTimestamp(),
      });

      await _loadSessions();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Study session cancelled'),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to cancel session: $e'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      );
    }
  }

  void _resetForm() {
    setState(() {
      if (_selectedPartnerId != null &&
          _partnerCommonCourses.containsKey(_selectedPartnerId)) {
        final commonCourses = _partnerCommonCourses[_selectedPartnerId]!;
        if (commonCourses.isNotEmpty) {
          _selectedCourse = commonCourses.first;
        } else {
          _selectedCourse = null;
        }
      } else {
        _selectedCourse = null;
      }

      _selectedDate = DateTime.now().add(const Duration(days: 1));
      _selectedTime = const TimeOfDay(hour: 14, minute: 0);
      _selectedLocation = 'Library';
      _selectedDuration = 60;
      _sessionNotes = '';
    });
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 90)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(primary: Colors.deepPurple),
          ),
          child: child!,
        );
      },
    );

    if (pickedDate != null && pickedDate != _selectedDate) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(primary: Colors.deepPurple),
          ),
          child: child!,
        );
      },
    );

    if (pickedTime != null && pickedTime != _selectedTime) {
      setState(() {
        _selectedTime = pickedTime;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F6FB),
      appBar: AppBar(
        title: const Text(
          'Study Sessions',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
        ),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(16),
            bottomRight: Radius.circular(16),
          ),
        ),
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.deepPurple.shade400,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.arrow_back_ios_new, size: 18),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        bottom:
            _hasError || studyPartners.isEmpty
                ? null 
                : TabBar(
                  controller: _tabController,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white70,
                  indicatorColor: Colors.white,
                  tabs: [
                    Tab(
                      icon: const Icon(Icons.add_circle_outline),
                      text: 'Schedule',
                      iconMargin: const EdgeInsets.only(bottom: 4),
                    ),
                    Tab(
                      icon: const Icon(Icons.calendar_today),
                      text: 'Upcoming',
                      iconMargin: const EdgeInsets.only(bottom: 4),
                    ),
                    Tab(
                      icon: Badge(
                        label: Text(_pendingSessions.length.toString()),
                        isLabelVisible: _pendingSessions.isNotEmpty,
                        child: const Icon(Icons.notifications_none),
                      ),
                      text: 'Requests',
                      iconMargin: const EdgeInsets.only(bottom: 4),
                    ),
                  ],
                ),
      ),
      body:
          _isLoading
              ? const Center(
                child: CircularProgressIndicator(color: Colors.deepPurple),
              )
              : _hasError
              ? _buildErrorState()
              : studyPartners.isEmpty
              ? _buildNoPartnersState()
              : TabBarView(
                controller: _tabController,
                children: [
                  SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: _buildScheduleForm(),
                  ),

                  _upcomingSessions.isEmpty
                      ? _buildEmptySessionsState(
                        'No upcoming study sessions',
                        'Schedule a study session to get started',
                      )
                      : _buildSessionsList(_upcomingSessions),

                  _buildPendingRequestsList(),
                ],
              ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(24),
        margin: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 64, color: Colors.red.shade300),
            const SizedBox(height: 24),
            Text(
              'Error Loading Data',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.red.shade700,
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                _errorMessage,
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade700, fontSize: 16),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _loadData,
              icon: const Icon(Icons.refresh),
              label: const Text("Try Again"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 12,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNoPartnersState() {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(24),
        margin: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.people_outline,
              size: 64,
              color: Colors.deepPurple.shade300,
            ),
            const SizedBox(height: 24),
            const Text(
              'No Study Partners Yet',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.deepPurple,
              ),
            ),
            const SizedBox(height: 16),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Connect with other students who share your courses to schedule study sessions.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black87, fontSize: 16),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () => Navigator.pushNamed(context, '/matches'),
              icon: const Icon(Icons.people),
              label: const Text("Find Study Partners"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 12,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptySessionsState(String title, String subtitle) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(24),
        margin: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.calendar_today_outlined,
              size: 64,
              color: Colors.deepPurple.shade300,
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.deepPurple,
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                subtitle,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black87, fontSize: 16),
              ),
            ),
            const SizedBox(height: 24),
            if (title.contains("No upcoming"))
              ElevatedButton.icon(
                onPressed: () {
                  _tabController.animateTo(0);
                },
                icon: const Icon(Icons.add_circle_outline),
                label: const Text("Schedule Session"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSessionsList(List<Map<String, dynamic>> sessions) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: sessions.length,
      itemBuilder: (context, index) {
        final session = sessions[index];
        return _buildSessionCard(session);
      },
    );
  }

  Widget _buildPendingRequestsList() {
    if (_pendingSessions.isEmpty) {
      return _buildEmptySessionsState(
        'No Session Requests',
        'When someone invites you to a study session, it will appear here',
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _pendingSessions.length,
      itemBuilder: (context, index) {
        final session = _pendingSessions[index];
        return _buildRequestCard(session);
      },
    );
  }

  Widget _buildSessionCard(Map<String, dynamic> session) {
    final sessionDate = session['dateTime'] as DateTime;
    final dateFormat = DateFormat('EEE, MMM d');
    final timeFormat = DateFormat('h:mm a');

    final isCreator = session['isCreator'] == true;
    final course = session['course'] as String;

    final prefix = course.split(' ').isNotEmpty ? course.split(' ').first : '';

    Color cardColor;
    Color textColor;
    switch (prefix) {
      case 'MTH':
        cardColor = const Color(0xFFE3F2FD);
        textColor = const Color(0xFF1565C0);
        break;
      case 'PHY':
        cardColor = const Color(0xFFF3E5F5);
        textColor = const Color(0xFF7B1FA2);
        break;
      case 'CHE':
        cardColor = const Color(0xFFE8F5E9);
        textColor = const Color(0xFF2E7D32);
        break;
      default:
        cardColor = const Color(0xFFEFEBE9);
        textColor = const Color(0xFF5D4037);
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: textColor.withOpacity(0.2),
                  child: Text(
                    prefix.isNotEmpty ? prefix[0] : 'C',
                    style: TextStyle(
                      color: textColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  course,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: textColor,
                  ),
                ),
                const Spacer(),
                if (session['status'] == 'pending')
                  if (session['status'] == 'pending')
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.orange.shade100,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.orange.shade300),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.pending_outlined,
                            size: 14,
                            color: Colors.orange.shade900,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Pending',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Colors.orange.shade900,
                            ),
                          ),
                        ],
                      ),
                    ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.person, size: 18, color: Colors.grey),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'With ${session['partnerName']}',
                        style: const TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),

                Row(
                  children: [
                    const Icon(
                      Icons.calendar_today,
                      size: 18,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      dateFormat.format(sessionDate),
                      style: const TextStyle(fontSize: 15),
                    ),
                    const SizedBox(width: 16),
                    const Icon(Icons.access_time, size: 18, color: Colors.grey),
                    const SizedBox(width: 8),
                    Text(
                      timeFormat.format(sessionDate),
                      style: const TextStyle(fontSize: 15),
                    ),
                  ],
                ),
                const SizedBox(height: 8),

                Row(
                  children: [
                    const Icon(Icons.location_on, size: 18, color: Colors.grey),
                    const SizedBox(width: 8),
                    Text(
                      session['location'] as String,
                      style: const TextStyle(fontSize: 15),
                    ),
                    const SizedBox(width: 16),
                    const Icon(Icons.timelapse, size: 18, color: Colors.grey),
                    const SizedBox(width: 8),
                    Text(
                      '${session['duration']} minutes',
                      style: const TextStyle(fontSize: 15),
                    ),
                  ],
                ),
                if (session['notes'] != null &&
                    session['notes'].toString().isNotEmpty) ...[
                  const SizedBox(height: 8),
                  const Divider(),
                  const SizedBox(height: 8),
                  const Text(
                    'Notes:',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    session['notes'].toString(),
                    style: const TextStyle(fontSize: 14),
                  ),
                ],

                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    if (isCreator)
                      OutlinedButton.icon(
                        onPressed: () => _cancelSession(session['id']),
                        icon: const Icon(Icons.cancel, size: 16),
                        label: const Text('Cancel'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.red,
                          side: BorderSide(color: Colors.red.shade300),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                      ),
                    const SizedBox(width: 12),
                    ElevatedButton.icon(
                      onPressed: () {
                        showModalBottomSheet(
                          context: context,

                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                              top: Radius.circular(20),
                            ),
                          ),
                          builder:
                              (context) => _buildSessionDetailsSheet(session),
                        );
                      },
                      icon: const Icon(Icons.info_outline, size: 16),
                      label: const Text('Details'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepPurple,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRequestCard(Map<String, dynamic> session) {
    final sessionDate = session['dateTime'] as DateTime;
    final dateFormat = DateFormat('EEE, MMM d');
    final timeFormat = DateFormat('h:mm a');

    final course = session['course'] as String;
    final partnerName = session['partnerName'] as String;

    final prefix = course.split(' ').isNotEmpty ? course.split(' ').first : '';

    Color cardColor;
    Color textColor;
    switch (prefix) {
      case 'MTH':
        cardColor = const Color(0xFFE3F2FD);
        textColor = const Color(0xFF1565C0);
        break;
      case 'PHY':
        cardColor = const Color(0xFFF3E5F5);
        textColor = const Color(0xFF7B1FA2);
        break;
      case 'CHE':
        cardColor = const Color(0xFFE8F5E9);
        textColor = const Color(0xFF2E7D32);
        break;
      default:
        cardColor = const Color(0xFFEFEBE9);
        textColor = const Color(0xFF5D4037);
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.deepPurple.shade50,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.notification_important,
                  color: Colors.deepPurple,
                  size: 24,
                ),
                const SizedBox(width: 12),
                Text(
                  "Session Request",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.deepPurple.shade700,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "$partnerName invited you to study",
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: cardColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircleAvatar(
                        radius: 12,
                        backgroundColor: textColor.withOpacity(0.2),
                        child: Text(
                          prefix.isNotEmpty ? prefix[0] : 'C',
                          style: TextStyle(
                            color: textColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 10,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        course,
                        style: TextStyle(
                          fontSize: 14,
                          color: textColor,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    const Icon(
                      Icons.calendar_today,
                      size: 18,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      dateFormat.format(sessionDate),
                      style: const TextStyle(fontSize: 15),
                    ),
                    const SizedBox(width: 16),
                    const Icon(Icons.access_time, size: 18, color: Colors.grey),
                    const SizedBox(width: 8),
                    Text(
                      timeFormat.format(sessionDate),
                      style: const TextStyle(fontSize: 15),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.location_on, size: 18, color: Colors.grey),
                    const SizedBox(width: 8),
                    Text(
                      session['location'] as String,
                      style: const TextStyle(fontSize: 15),
                    ),
                    const SizedBox(width: 16),
                    const Icon(Icons.timelapse, size: 18, color: Colors.grey),
                    const SizedBox(width: 8),
                    Text(
                      '${session['duration']} minutes',
                      style: const TextStyle(fontSize: 15),
                    ),
                  ],
                ),

                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed:
                            () => _respondToSession(session['id'], false),
                        icon: const Icon(Icons.close, size: 18),
                        label: const Text('Decline'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.red.shade700,
                          side: BorderSide(color: Colors.red.shade300),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => _respondToSession(session['id'], true),
                        icon: const Icon(Icons.check, size: 18),
                        label: const Text('Accept'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          elevation: 1,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSessionDetailsSheet(Map<String, dynamic> session) {

    final sessionDate = session['dateTime'] as DateTime;
    final dateFormat = DateFormat('EEEE, MMMM d, yyyy');
    final timeFormat = DateFormat('h:mm a');

    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.school, size: 24, color: Colors.deepPurple),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Study Session Details',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.deepPurple,
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
          const Divider(height: 24),

          const Text(
            'Course',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            session['course'] as String,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),

          const Text(
            'Date & Time',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '${dateFormat.format(sessionDate)} at ${timeFormat.format(sessionDate)}',
            style: const TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 16),

          const Text(
            'Location',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            session['location'] as String,
            style: const TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 16),

          const Text(
            'Duration',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '${session['duration']} minutes',
            style: const TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 16),
          const Text(
            'Study Partner',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            session['partnerName'] as String,
            style: const TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 16),

          const Text(
            'Status',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          _buildStatusChip(session['status'] as String),
          const SizedBox(height: 16),
          if (session['notes'] != null &&
              session['notes'].toString().isNotEmpty) ...[
            const Text(
              'Notes',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              session['notes'].toString(),
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),
          ],

          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              OutlinedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.close),
                label: const Text('Close'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.grey.shade700,
                  side: BorderSide(color: Colors.grey.shade300),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              if (session['createdBy'] ==
                      FirebaseAuth.instance.currentUser?.uid &&
                  session['status'] != 'cancelled')
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.pop(context);
                    _cancelSession(session['id']);
                  },
                  icon: const Icon(Icons.cancel_outlined),
                  label: const Text('Cancel Session'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatusChip(String status) {
    Color bgColor;
    Color textColor;
    IconData icon;
    String label;

    switch (status) {
      case 'scheduled':
        bgColor = Colors.green.shade100;
        textColor = Colors.green.shade800;
        icon = Icons.check_circle_outline;
        label = 'Scheduled';
        break;
      case 'pending':
        bgColor = Colors.orange.shade100;
        textColor = Colors.orange.shade800;
        icon = Icons.pending_outlined;
        label = 'Pending';
        break;
      case 'cancelled':
        bgColor = Colors.red.shade100;
        textColor = Colors.red.shade800;
        icon = Icons.cancel_outlined;
        label = 'Cancelled';
        break;
      case 'completed':
        bgColor = Colors.blue.shade100;
        textColor = Colors.blue.shade800;
        icon = Icons.done_all;
        label = 'Completed';
        break;
      default:
        bgColor = Colors.grey.shade100;
        textColor = Colors.grey.shade800;
        icon = Icons.help_outline;
        label = 'Unknown';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: textColor),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(color: textColor, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildScheduleForm() {
    return Form(
      key: _formKey,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Select Study Partner',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: DropdownButtonFormField<String>(
                value: _selectedPartnerId,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.person),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 16),
                ),
                items:
                    studyPartners.map((partner) {
                      return DropdownMenuItem<String>(
                        value: partner['id'],
                        child: Text(partner['name']),
                      );
                    }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedPartnerId = value;
                    _selectedPartnerName =
                        studyPartners.firstWhere(
                          (partner) => partner['id'] == value,
                        )['name'];

                    if (_partnerCommonCourses.containsKey(_selectedPartnerId)) {
                      final commonCourses =
                          _partnerCommonCourses[_selectedPartnerId]!;
                      if (commonCourses.isNotEmpty) {
                        _selectedCourse = commonCourses.first;
                      } else {
                        _selectedCourse = null;
                      }
                    }
                  });
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please select a study partner';
                  }
                  return null;
                },
                isExpanded: true,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Select Course',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: DropdownButtonFormField<String>(
                value: _selectedCourse,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.book),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 16),
                ),
                items:
                    (_selectedPartnerId != null &&
                            _partnerCommonCourses.containsKey(
                              _selectedPartnerId,
                            ))
                        ? _partnerCommonCourses[_selectedPartnerId]!.map((
                          course,
                        ) {
                          return DropdownMenuItem<String>(
                            value: course,
                            child: Text(course),
                          );
                        }).toList()
                        : [], 
                onChanged: (value) {
                  setState(() {
                    _selectedCourse = value;
                  });
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please select a course';
                  }
                  return null;
                },
                isExpanded: true,
              ),
            ),
            const SizedBox(height: 20),

            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Date & Time',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 8),
              
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: () => _selectDate(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 12,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade50,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey.shade300),
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.calendar_today,
                                size: 18,
                                color: Colors.grey,
                              ),
                              const SizedBox(width: 8),
                              Flexible(
                                child: Text(
                                  DateFormat(
                                    'EEE, MMM d, yyyy',
                                  ).format(_selectedDate),
                                  style: const TextStyle(fontSize: 14),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(width: 12),


                    Expanded(
                      child: InkWell(
                        onTap: () => _selectTime(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 12,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade50,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey.shade300),
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.access_time,
                                size: 18,
                                color: Colors.grey,
                              ),
                              const SizedBox(width: 8),
                              Flexible(
                       
                                child: Text(
                                  _selectedTime.format(context),
                                  style: const TextStyle(fontSize: 14),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),

            const Text(
              'Location',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: DropdownButtonFormField<String>(
                value: _selectedLocation,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.location_on),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 16),
                ),
                items:
                    [
                      'Library',
                      'Coffee Shop',
                      'Study Room',
                      'Classroom',
                      'Online',
                      'Other',
                    ].map((location) {
                      return DropdownMenuItem<String>(
                        value: location,
                        child: Text(location),
                      );
                    }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedLocation = value!;
                  });
                },
                isExpanded: true,
              ),
            ),
            const SizedBox(height: 20),


            const Text(
              'Duration',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Text('30 min'),
                Expanded(
                  child: Slider(
                    value: _selectedDuration.toDouble(),
                    min: 30,
                    max: 180,
                    divisions: 5,
                    activeColor: Colors.deepPurple,
                    inactiveColor: Colors.deepPurple.withOpacity(0.2),
                    label: '$_selectedDuration min',
                    onChanged: (value) {
                      setState(() {
                        _selectedDuration = value.toInt();
                      });
                    },
                  ),
                ),
                const Text('3 hrs'),
              ],
            ),
            Center(
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: Colors.deepPurple.shade50,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.deepPurple.shade100),
                ),
                child: Text(
                  '$_selectedDuration minutes',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.deepPurple.shade700,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),


            const Text(
              'Notes (Optional)',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: TextFormField(
                initialValue: _sessionNotes,
                onChanged: (value) {
                  _sessionNotes = value;
                },
                maxLines: 3,
                decoration: const InputDecoration(
                  hintText:
                      'Add any additional notes for this study session...',
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.all(16),
                ),
              ),
            ),
            const SizedBox(height: 24),


            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: _isSaving ? null : _scheduleSession,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  foregroundColor: Colors.white,
                  disabledBackgroundColor: Colors.deepPurple.withOpacity(0.6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 2,
                  shadowColor: Colors.deepPurple.withOpacity(0.3),
                ),
                child:
                    _isSaving
                        ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2.0,
                          ),
                        )
                        : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(Icons.calendar_today),
                            SizedBox(width: 10),
                            Text(
                              'Schedule Study Session',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
