import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../services/notification_service.dart' as notifService;
import '../screens/chat_screen.dart' as chatScreen;
import '../screens/study_session_scheduling_screen.dart';

class NotificationListScreen extends StatefulWidget {
  const NotificationListScreen({super.key});

  @override
  State<NotificationListScreen> createState() => _NotificationListScreenState();
}

class _NotificationListScreenState extends State<NotificationListScreen> {
  final notifService.NotificationService _notificationService =
      notifService.NotificationService();

  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _markAllAsRead();
  }

  Future<void> _markAllAsRead() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await _notificationService.markAllNotificationsAsRead();
    } catch (e) {
      print('Error marking notifications as read: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          IconButton(
            icon: const Icon(Icons.done_all),
            onPressed: _markAllAsRead,
            tooltip: 'Mark all as read',
          ),
        ],
      ),
      body:
          _isLoading
              ? const Center(child: CircularProgressIndicator())
              : StreamBuilder<QuerySnapshot>(
                stream: _notificationService.getUserNotifications(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  }

                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.notifications_off,
                            size: 64,
                            color: Colors.grey.shade400,
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'No notifications yet',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'When you receive notifications, they will appear here',
                            style: TextStyle(color: Colors.grey.shade600),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    );
                  }

                  final notifications = snapshot.data!.docs;

                  return ListView.builder(
                    itemCount: notifications.length,
                    padding: const EdgeInsets.all(16),
                    itemBuilder: (context, index) {
                      final notification = notifications[index];
                      final data = notification.data() as Map<String, dynamic>;

                      final String id = notification.id;
                      final String type = data['type'] ?? 'default';
                      final String message =
                          data['message'] ?? 'New notification';
                      final Timestamp timestamp =
                          data['timestamp'] ?? Timestamp.now();
                      final bool isRead = data['read'] ?? false;

                      return Dismissible(
                        key: Key(id),
                        background: Container(
                          color: Colors.red,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 16),
                          child: const Icon(Icons.delete, color: Colors.white),
                        ),
                        direction: DismissDirection.endToStart,
                        onDismissed: (direction) {
                          _notificationService.deleteNotification(id);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Notification deleted'),
                            ),
                          );
                        },
                        child: Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          color:
                              isRead ? Colors.white : Colors.deepPurple.shade50,
                          child: ListTile(
                            leading: _getNotificationIcon(type, isRead),
                            title: Text(
                              message,
                              style: TextStyle(
                                fontWeight:
                                    isRead
                                        ? FontWeight.normal
                                        : FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(
                              _formatTimestamp(timestamp),
                              style: TextStyle(color: Colors.grey.shade600),
                            ),
                            onTap: () {
                              _notificationService.markNotificationAsRead(id);
                              _handleNotificationTap(data);
                            },
                            trailing:
                                isRead
                                    ? null
                                    : Icon(
                                      Icons.circle,
                                      size: 12,
                                      color: Colors.deepPurple,
                                    ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
    );
  }

  Widget _getNotificationIcon(String type, bool isRead) {
    IconData icon;
    Color color;

    switch (type) {
      case 'connection_request':
        icon = Icons.person_add;
        color = Colors.blue;
        break;
      case 'connection_accepted':
        icon = Icons.people;
        color = Colors.green;
        break;
      case 'study_session_invitation':
        icon = Icons.calendar_today;
        color = Colors.orange;
        break;
      case 'study_session_response':
        icon = Icons.event_available;
        color = Colors.deepPurple;
        break;
      case 'message':
        icon = Icons.message;
        color = Colors.indigo;
        break;
      default:
        icon = Icons.notifications;
        color = Colors.grey;
    }

    return CircleAvatar(
      backgroundColor: isRead ? color.withOpacity(0.2) : color.withOpacity(0.8),
      child: Icon(
        icon,
        color: isRead ? color.withOpacity(0.5) : Colors.white,
        size: 20,
      ),
    );
  }

  String _formatTimestamp(Timestamp timestamp) {
    final now = DateTime.now();
    final dateTime = timestamp.toDate();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inHours < 1) {
      final minutes = difference.inMinutes;
      return '$minutes ${minutes == 1 ? 'minute' : 'minutes'} ago';
    } else if (difference.inDays < 1) {
      final hours = difference.inHours;
      return '$hours ${hours == 1 ? 'hour' : 'hours'} ago';
    } else if (difference.inDays < 7) {
      final days = difference.inDays;
      return '$days ${days == 1 ? 'day' : 'days'} ago';
    } else {
      // Format as Mon DD, YYYY
      return DateFormat('MMM d, yyyy').format(dateTime);
    }
  }

  void _handleNotificationTap(Map<String, dynamic> data) {
    final type = data['type'] ?? 'default';

    switch (type) {
      case 'connection_request':
        Navigator.pushReplacementNamed(context, '/matches');
        break;
      case 'connection_accepted':
        Navigator.pushReplacementNamed(context, '/matches');
        break;
      case 'study_session_invitation':
      case 'study_session_response':
        if (data['senderId'] != null) {
          // Extract session information if available
          final senderId = data['senderId'];
          final senderName = data['senderName'] ?? 'Study Partner';

          // Get courses info if available in sessionInfo
          List<String> commonCourses = [];
          if (data['sessionInfo'] != null &&
              data['sessionInfo']['course'] != null) {
            commonCourses.add(data['sessionInfo']['course']);
          }

          // Navigate to the study session screen
          Navigator.push(
            context,
            MaterialPageRoute(
              builder:
                  (context) => StudySessionScreen(
                    partnerId: senderId,
                    partnerName: senderName,
                    commonCourses: commonCourses,
                  ),
            ),
          );
        }
        break;
      case 'message':
        if (data['senderId'] != null && data['senderName'] != null) {
          final senderId = data['senderId'];
          final senderName = data['senderName'];
          final senderEmail = data['senderEmail'] ?? '';

          Navigator.push(
            context,
            MaterialPageRoute(
              builder:
                  (context) => chatScreen.ChatScreen(
                    receiverId: senderId,
                    receiverName: senderName,
                    receiverEmail: senderEmail,
                  ),
            ),
          );
        }
        break;
      default:
        break;
    }
  }
}
