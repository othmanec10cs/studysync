

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class StudyPreferencesScreen extends StatefulWidget {
  const StudyPreferencesScreen({super.key});

  @override
  State<StudyPreferencesScreen> createState() => _StudyPreferencesScreenState();
}

class _StudyPreferencesScreenState extends State<StudyPreferencesScreen>
    with SingleTickerProviderStateMixin {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  bool _isLoading = true;
  bool _isSaving = false;
  Map<String, dynamic> _preferences = {};


  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;


  final Map<String, List<String>> _preferenceOptions = {
    'studyTimes': ['Morning', 'Afternoon', 'Evening', 'Night'],
    'environment': ['Library', 'Coffee Shop', 'Home', 'Outdoors', 'Virtual'],
    'learningStyle': ['Visual', 'Auditory', 'Reading/Writing', 'Kinesthetic'],
    'communicationPref': ['Video Call', 'Audio Call', 'Chat', 'In-person'],
    'studyGroupSize': ['One-on-one', 'Small group (3-5)', 'Large group (6+)'],
  };

  List<String> _selectedStudyTimes = [];
  String? _selectedEnvironment;
  String? _selectedLearningStyle;
  String? _selectedCommunicationPref;
  String? _selectedGroupSize;


  bool _isLearningStylesExpanded = false;

  @override
  void initState() {
    super.initState();

 
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _loadData().then((_) {
      if (mounted) {
        _animationController.forward();
      }
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);

    try {

      final user = _auth.currentUser;
      if (user != null) {
        final doc = await _firestore.collection('users').doc(user.uid).get();
        final userData = doc.data();

        if (userData != null && userData.containsKey('studyPreferences')) {
          _preferences = Map<String, dynamic>.from(
            userData['studyPreferences'],
          );


          _selectedStudyTimes = List<String>.from(
            _preferences['studyTimes'] ?? [],
          );
          _selectedEnvironment = _preferences['environment'];
          _selectedLearningStyle = _preferences['learningStyle'];
          _selectedCommunicationPref = _preferences['communicationPref'];
          _selectedGroupSize = _preferences['studyGroupSize'];
        }
      }
    } catch (e) {
      print('Error loading preferences: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error loading preferences: $e'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _savePreferences() async {
    setState(() => _isSaving = true);

    try {
  
      final preferences = {
        'studyTimes': _selectedStudyTimes,
        'environment': _selectedEnvironment,
        'learningStyle': _selectedLearningStyle,
        'communicationPref': _selectedCommunicationPref,
        'studyGroupSize': _selectedGroupSize,
      };

      final user = _auth.currentUser;
      if (user != null) {
        await _firestore.collection('users').doc(user.uid).update({
          'studyPreferences': preferences,
          'lastUpdated': FieldValue.serverTimestamp(),
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Study preferences saved successfully!'),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      print('Error saving preferences: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error saving preferences: $e'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      );
    } finally {
      setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F6FB),
      appBar: AppBar(
        title: const Text(
          'Study Preferences',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
        ),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(16),
            bottomRight: Radius.circular(16),
          ),
        ),
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.deepPurple.shade400,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.arrow_back_ios_new, size: 18),
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body:
          _isLoading
              ? const Center(
                child: CircularProgressIndicator(color: Colors.deepPurple),
              )
              : FadeTransition(
                opacity: _fadeAnimation,
                child: Stack(
                  children: [
                    _buildPreferencesContent(),
                    Positioned(
                      bottom: 0,
                      left: 0,
                      right: 0,
                      child: _buildSaveButton(),
                    ),
                  ],
                ),
              ),
    );
  }

  Widget _buildPreferencesContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(
        20,
        20,
        20,
        100,
      ), 
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: const Text(
              'Set your study preferences to find better matches',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          const SizedBox(height: 30),

          const Text(
            'When do you prefer to study?',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children:
                _preferenceOptions['studyTimes']!.map((time) {
                  return FilterChip(
                    label: Text(time),
                    labelStyle: TextStyle(
                      fontWeight:
                          _selectedStudyTimes.contains(time)
                              ? FontWeight.bold
                              : FontWeight.normal,
                      color:
                          _selectedStudyTimes.contains(time)
                              ? Colors.deepPurple.shade700
                              : Colors.black87,
                    ),
                    selected: _selectedStudyTimes.contains(time),
                    onSelected: (selected) {
                      setState(() {
                        if (selected) {
                          _selectedStudyTimes.add(time);
                        } else {
                          _selectedStudyTimes.remove(time);
                        }
                      });
                    },
                    backgroundColor: Colors.white,
                    selectedColor: Colors.deepPurple.shade100,
                    checkmarkColor: Colors.deepPurple,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                      side: BorderSide(
                        color:
                            _selectedStudyTimes.contains(time)
                                ? Colors.deepPurple.shade300
                                : Colors.grey.shade300,
                      ),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                  );
                }).toList(),
          ),
          const SizedBox(height: 30),

          const Text(
            'Preferred study environment',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children:
                _preferenceOptions['environment']!.map((env) {
                  return ChoiceChip(
                    label: Text(env),
                    labelStyle: TextStyle(
                      fontWeight:
                          _selectedEnvironment == env
                              ? FontWeight.bold
                              : FontWeight.normal,
                      color:
                          _selectedEnvironment == env
                              ? Colors.deepPurple.shade700
                              : Colors.black87,
                    ),
                    selected: _selectedEnvironment == env,
                    onSelected: (selected) {
                      setState(() {
                        _selectedEnvironment = selected ? env : null;
                      });
                    },
                    backgroundColor: Colors.white,
                    selectedColor: Colors.deepPurple.shade100,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                      side: BorderSide(
                        color:
                            _selectedEnvironment == env
                                ? Colors.deepPurple.shade300
                                : Colors.grey.shade300,
                      ),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                  );
                }).toList(),
          ),
          const SizedBox(height: 30),

          const Text(
            'Your learning style',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children:
                _preferenceOptions['learningStyle']!.map((style) {
                  return ChoiceChip(
                    label: Text(style),
                    labelStyle: TextStyle(
                      fontWeight:
                          _selectedLearningStyle == style
                              ? FontWeight.bold
                              : FontWeight.normal,
                      color:
                          _selectedLearningStyle == style
                              ? Colors.deepPurple.shade700
                              : Colors.black87,
                    ),
                    selected: _selectedLearningStyle == style,
                    onSelected: (selected) {
                      setState(() {
                        _selectedLearningStyle = selected ? style : null;
                      });
                    },
                    backgroundColor: Colors.white,
                    selectedColor: Colors.deepPurple.shade100,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                      side: BorderSide(
                        color:
                            _selectedLearningStyle == style
                                ? Colors.deepPurple.shade300
                                : Colors.grey.shade300,
                      ),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                  );
                }).toList(),
          ),
          const SizedBox(height: 30),

          const Text(
            'Preferred communication method',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children:
                _preferenceOptions['communicationPref']!.map((pref) {
                  return ChoiceChip(
                    label: Text(pref),
                    labelStyle: TextStyle(
                      fontWeight:
                          _selectedCommunicationPref == pref
                              ? FontWeight.bold
                              : FontWeight.normal,
                      color:
                          _selectedCommunicationPref == pref
                              ? Colors.deepPurple.shade700
                              : Colors.black87,
                    ),
                    selected: _selectedCommunicationPref == pref,
                    onSelected: (selected) {
                      setState(() {
                        _selectedCommunicationPref = selected ? pref : null;
                      });
                    },
                    backgroundColor: Colors.white,
                    selectedColor: Colors.deepPurple.shade100,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                      side: BorderSide(
                        color:
                            _selectedCommunicationPref == pref
                                ? Colors.deepPurple.shade300
                                : Colors.grey.shade300,
                      ),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                  );
                }).toList(),
          ),
          const SizedBox(height: 30),

          const Text(
            'Preferred study group size',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children:
                _preferenceOptions['studyGroupSize']!.map((size) {
                  return ChoiceChip(
                    label: Text(size),
                    labelStyle: TextStyle(
                      fontWeight:
                          _selectedGroupSize == size
                              ? FontWeight.bold
                              : FontWeight.normal,
                      color:
                          _selectedGroupSize == size
                              ? Colors.deepPurple.shade700
                              : Colors.black87,
                    ),
                    selected: _selectedGroupSize == size,
                    onSelected: (selected) {
                      setState(() {
                        _selectedGroupSize = selected ? size : null;
                      });
                    },
                    backgroundColor: Colors.white,
                    selectedColor: Colors.deepPurple.shade100,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                      side: BorderSide(
                        color:
                            _selectedGroupSize == size
                                ? Colors.deepPurple.shade300
                                : Colors.grey.shade300,
                      ),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                  );
                }).toList(),
          ),
          const SizedBox(height: 30),


          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.deepPurple.shade50,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.deepPurple.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.lightbulb, color: Colors.deepPurple.shade700),
                    const SizedBox(width: 8),
                    const Text(
                      'Why set preferences?',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.deepPurple,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                const Text(
                  'Setting your study preferences helps us match you with compatible study partners. '
                  'Students with similar preferences tend to have more productive study sessions!',
                  style: TextStyle(fontSize: 15),
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),

          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: ExpansionTile(
              title: const Text(
                'Understanding Learning Styles',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              initiallyExpanded: _isLearningStylesExpanded,
              onExpansionChanged: (expanded) {
                setState(() {
                  _isLearningStylesExpanded = expanded;
                });
              },
              trailing: Icon(
                _isLearningStylesExpanded
                    ? Icons.keyboard_arrow_up
                    : Icons.keyboard_arrow_down,
                color: Colors.deepPurple,
              ),
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(16)),
              ),
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildLearningStyleInfo(
                        'Visual',
                        'You learn best through seeing graphs, charts, and images',
                        Icons.visibility,
                        Colors.blue,
                      ),
                      const SizedBox(height: 16),
                      _buildLearningStyleInfo(
                        'Auditory',
                        'You learn best through listening to lectures and discussions',
                        Icons.hearing,
                        Colors.purple,
                      ),
                      const SizedBox(height: 16),
                      _buildLearningStyleInfo(
                        'Reading/Writing',
                        'You learn best through reading texts and writing notes',
                        Icons.menu_book,
                        Colors.green,
                      ),
                      const SizedBox(height: 16),
                      _buildLearningStyleInfo(
                        'Kinesthetic',
                        'You learn best through hands-on activities and practice',
                        Icons.touch_app,
                        Colors.orange,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  Widget _buildSaveButton() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: SizedBox(
          width: double.infinity,
          height: 56,
          child: ElevatedButton(
            onPressed: _isSaving ? null : _savePreferences,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.deepPurple,
              foregroundColor: Colors.white,
              disabledBackgroundColor: Colors.deepPurple.withOpacity(0.6),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 2,
              shadowColor: Colors.deepPurple.withOpacity(0.3),
            ),
            child:
                _isSaving
                    ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2.0,
                      ),
                    )
                    : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.save),
                        SizedBox(width: 10),
                        Text(
                          'Save Preferences',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
          ),
        ),
      ),
    );
  }

  Widget _buildLearningStyleInfo(
    String title,
    String description,
    IconData icon,
    Color color,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color, size: 24),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: color.withOpacity(0.8),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                description,
                style: const TextStyle(fontSize: 14, color: Colors.black87),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
