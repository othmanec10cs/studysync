/*
 * CourseSelectionScreen manages user course enrollment and selection.
 * Provides interface for adding and removing courses from user profile.
 * Integrates with database to store course selections and update
 * matching criteria for study partner discovery.
 */

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart' show rootBundle;

import 'dashboard_screen.dart';

class CourseSelectionScreen extends StatefulWidget {
  const CourseSelectionScreen({super.key});

  @override
  State<CourseSelectionScreen> createState() => _CourseSelectionScreenState();
}

class _CourseSelectionScreenState extends State<CourseSelectionScreen>
    with SingleTickerProviderStateMixin {
  List<Map<String, String>> allCourses = [];
  List<Map<String, String>> filteredCourses = [];
  final Set<String> selectedCourseCodes = {};
  final TextEditingController searchController = TextEditingController();
  bool isLoading = true;
  bool hasError = false;
  String errorMessage = "";

 
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    if (FirebaseAuth.instance.currentUser == null) {
    
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).pushReplacementNamed('/login');
      });
      return;
    }

    loadCourses().then((_) {
      fetchUserCourses().then((_) {
        if (mounted) {
          _animationController.forward();
        }
      });
    });
  }

  @override
  void dispose() {
    searchController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> loadCourses() async {
    try {
      final String jsonString = await rootBundle.loadString(
        'assets/aui_courses.json',
      );
      final List<dynamic> jsonData = json.decode(jsonString);
      if (mounted) {
        setState(() {
          allCourses =
              jsonData
                  .map(
                    (course) => {
                      'Course Code': course['Course Code']?.toString() ?? '',
                      'Course Name': course['Course Name']?.toString() ?? '',
                    },
                  )
                  .toList();
          filteredCourses = List.from(allCourses);
        });
      }
    } catch (e) {
      print('Error loading courses: $e');
      if (mounted) {
        setState(() {
          hasError = true;
          errorMessage = "Failed to load course list: $e";
        });
      }
    }
  }

  Future<void> fetchUserCourses() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        print('User not authenticated, redirecting to login');
        if (mounted) {
          Navigator.of(context).pushReplacementNamed('/login');
        }
        return;
      }
      await user.reload();

      try {
        final doc =
            await FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .get();
        final data = doc.data();
        final courses = List<String>.from(data?['courses'] ?? []);
        if (mounted) {
          setState(() {
            selectedCourseCodes.addAll(courses);
            isLoading = false;
          });
        }
      } catch (e) {
        print('Error fetching user courses: $e');
        
        if (e.toString().contains('permission-denied')) {
          if (mounted) {
            setState(() {
              isLoading = false;
              hasError = true;
              errorMessage =
                  "Permission denied when accessing your data. Please check your Firebase security rules.";
            });
          }
        } else {
          if (mounted) {
            setState(() {
              isLoading = false;
              hasError = true;
              errorMessage = "Failed to load your courses: $e";
            });
          }
        }
      }
    } catch (e) {
      print('General error: $e');
      if (mounted) {
        setState(() {
          isLoading = false;
          hasError = true;
          errorMessage = "An error occurred: $e";
        });
      }
    }
  }

  void filterCourses(String query) {
    setState(() {
      filteredCourses =
          allCourses.where((course) {
            final code = course['Course Code']!.toLowerCase();
            final name = course['Course Name']!.toLowerCase();
            return code.contains(query.toLowerCase()) ||
                name.contains(query.toLowerCase());
          }).toList();
    });
  }

  Future<void> saveCoursesToFirestore() async {
    setState(() {
      isLoading = true;
    });

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please login to save courses.'),
            backgroundColor: Colors.red,
          ),
        );

        setState(() {
          isLoading = false;
        });

        Navigator.of(context).pushReplacementNamed('/login');
      }
      return;
    }

    await user.reload();

    if (selectedCourseCodes.isNotEmpty) {
      try {
        final normalizedCourses =
            selectedCourseCodes
                .map((code) => code.toString().toLowerCase())
                .toList();

        await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
          'courses': selectedCourseCodes.toList(),
          'normalizedCourses': normalizedCourses,
          'email': user.email,
          'lastUpdated': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));

        if (!mounted) return;

        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Courses saved successfully!'),
            backgroundColor: Colors.green,
          ),
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const DashboardScreen()),
        );
      } catch (e) {
        if (!mounted) return;

        if (e.toString().contains('permission-denied')) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Permission denied. Please check your Firebase security rules.',
              ),
              backgroundColor: Colors.red,
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error saving courses: $e'),
              backgroundColor: Colors.red,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }
      }
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please select at least one course.'),
          backgroundColor: Colors.orange.shade700,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          action: SnackBarAction(
            label: 'OK',
            textColor: Colors.white,
            onPressed: () {},
          ),
        ),
      );
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
   
    if (FirebaseAuth.instance.currentUser == null) {
     
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).pushReplacementNamed('/login');
      });
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return WillPopScope(
      onWillPop: () async {
        final shouldLogout = await showDialog<bool>(
          context: context,
          builder:
              (context) => AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                title: Row(
                  children: [
                    Icon(Icons.logout, color: Colors.red.shade300),
                    const SizedBox(width: 10),
                    const Text('Log out?'),
                  ],
                ),
                content: const Text(
                  'You need to select courses to continue. Do you want to log out instead?',
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: const Text('Cancel'),
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      await FirebaseAuth.instance.signOut();
                      if (!mounted) return;
                      Navigator.of(context).pop(true);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text('Log Out'),
                  ),
                ],
              ),
        );

        return shouldLogout ?? false;
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFF4F0F8),
        appBar: AppBar(
          title: const Text(
            "Select Your Courses",
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.deepPurple,
          foregroundColor: Colors.white,
          elevation: 0,
          automaticallyImplyLeading: false,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(16),
              bottomRight: Radius.circular(16),
            ),
          ),
        ),
        body:
            isLoading
                ? const Center(
                  child: CircularProgressIndicator(color: Colors.deepPurple),
                )
                : hasError
                ? _buildErrorState()
                : FadeTransition(
                  opacity: _fadeAnimation,
                  child: _buildCourseSelectionContent(),
                ),
        bottomNavigationBar:
            isLoading
                ? null
                : !hasError
                ? SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            vertical: 10,
                            horizontal: 16,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.deepPurple.shade50,
                            borderRadius: BorderRadius.circular(30),
                            border: Border.all(
                              color:
                                  selectedCourseCodes.isEmpty
                                      ? Colors.grey.shade300
                                      : Colors.green.shade300,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.check_circle,
                                size: 18,
                                color:
                                    selectedCourseCodes.isEmpty
                                        ? Colors.grey
                                        : Colors.green,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                '${selectedCourseCodes.length} courses selected',
                                style: TextStyle(
                                  color:
                                      selectedCourseCodes.isEmpty
                                          ? Colors.grey
                                          : Colors.green,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: ElevatedButton(
                            onPressed:
                                selectedCourseCodes.isEmpty || isLoading
                                    ? null
                                    : saveCoursesToFirestore,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.deepPurple,
                              disabledBackgroundColor: Colors.grey.shade400,
                              foregroundColor: Colors.white,
                              disabledForegroundColor: Colors.white70,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 3,
                              shadowColor: Colors.deepPurple.withOpacity(0.3),
                            ),
                            child:
                                isLoading
                                    ? Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: const [
                                        SizedBox(
                                          width: 24,
                                          height: 24,
                                          child: CircularProgressIndicator(
                                            color: Colors.white,
                                            strokeWidth: 2.0,
                                          ),
                                        ),
                                        SizedBox(width: 12),
                                        Text(
                                          "Saving...",
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    )
                                    : Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: const [
                                        Icon(Icons.arrow_forward),
                                        SizedBox(width: 8),
                                        Text(
                                          "Save & Continue",
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
                : null,
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(24),
        margin: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 64, color: Colors.red.shade300),
            const SizedBox(height: 24),
            Text(
              'Error Loading Data',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.red.shade700,
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                errorMessage,
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade700, fontSize: 16),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                setState(() {
                  isLoading = true;
                  hasError = false;
                });
                fetchUserCourses();
              },
              icon: const Icon(Icons.refresh),
              label: const Text("Try Again"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 12,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextButton.icon(
              onPressed: () async {
                await FirebaseAuth.instance.signOut();
                if (!mounted) return;
                Navigator.of(context).pushReplacementNamed('/login');
              },
              icon: const Icon(Icons.logout),
              label: const Text("Log Out and Try Again"),
              style: TextButton.styleFrom(
                foregroundColor: Colors.grey.shade700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCourseSelectionContent() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            controller: searchController,
            decoration: InputDecoration(
              hintText: 'Search courses by name or code...',
              prefixIcon: const Icon(Icons.search, color: Colors.deepPurple),
              suffixIcon:
                  searchController.text.isNotEmpty
                      ? IconButton(
                        icon: const Icon(Icons.clear, color: Colors.grey),
                        onPressed: () {
                          searchController.clear();
                          filterCourses('');
                        },
                      )
                      : null,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.symmetric(vertical: 16),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(
                  color: Colors.deepPurple,
                  width: 2,
                ),
              ),
            ),
            onChanged: filterCourses,
            style: const TextStyle(fontSize: 16),
          ),
        ),
        Expanded(
          child:
              filteredCourses.isEmpty
                  ? _buildNoResultsFound()
                  : ListView.builder(
                    itemCount: filteredCourses.length,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemBuilder: (context, index) {
                      final course = filteredCourses[index];
                      final code = course['Course Code']!;
                      final name = course['Course Name']!;
                      final isSelected = selectedCourseCodes.contains(code);

                    
                      final prefix = code.split(' ').first;
                      Color cardColor;
                      Color textColor;

                      switch (prefix) {
                        case 'MTH':
                          cardColor = const Color(0xFFE3F2FD);
                          textColor = const Color(0xFF1565C0);
                          break;
                        case 'PHY':
                          cardColor = const Color(0xFFF3E5F5);
                          textColor = const Color(0xFF7B1FA2);
                          break;
                        case 'CHE':
                          cardColor = const Color(0xFFE8F5E9);
                          textColor = const Color(0xFF2E7D32);
                          break;
                        default:
                          cardColor = const Color(0xFFEFEBE9);
                          textColor = const Color(0xFF5D4037);
                      }

                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        elevation: isSelected ? 2 : 1,
                        shadowColor:
                            isSelected
                                ? textColor.withOpacity(0.3)
                                : Colors.black12,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                          side:
                              isSelected
                                  ? BorderSide(color: textColor, width: 2)
                                  : BorderSide.none,
                        ),
                        color: isSelected ? cardColor : Colors.white,
                        child: CheckboxListTile(
                          title: Text(
                            code,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: isSelected ? textColor : Colors.black87,
                            ),
                          ),
                          subtitle: Text(
                            name,
                            style: TextStyle(
                              color:
                                  isSelected
                                      ? textColor.withOpacity(0.8)
                                      : Colors.black54,
                            ),
                          ),
                          value: isSelected,
                          activeColor: textColor,
                          checkColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          secondary: CircleAvatar(
                            backgroundColor: cardColor,
                            child: Text(
                              code.split(' ').first.substring(0, 1),
                              style: TextStyle(
                                color: textColor,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          onChanged: (bool? selected) {
                            setState(() {
                              if (selected == true) {
                                selectedCourseCodes.add(code);
                              } else {
                                selectedCourseCodes.remove(code);
                              }
                            });
                          },
                        ),
                      );
                    },
                  ),
        ),
      ],
    );
  }

  Widget _buildNoResultsFound() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.search_off, size: 64, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Text(
            'No courses found',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey.shade700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Try adjusting your search terms',
            style: TextStyle(color: Colors.grey.shade600),
          ),
        ],
      ),
    );
  }
}
