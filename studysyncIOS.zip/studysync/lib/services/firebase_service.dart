import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// A service to handle Firebase initialization and connectivity checks
class FirebaseService {
  static bool _isInitialized = false;
  static int _initAttempts = 0;
  static const int maxInitAttempts = 3;

  /// Initialize Firebase with retry capability
  static Future<bool> initializeFirebase() async {
    if (_isInitialized) return true;

    _initAttempts++;
    print("🔥 Firebase initialization attempt $_initAttempts");

    try {
      // If already initialized, just return success
      if (Firebase.apps.isNotEmpty) {
        _isInitialized = true;
        return true;
      }

      await Firebase.initializeApp(
        options: const FirebaseOptions(
          apiKey: "AIzaSyBkdQACP2fm8oJdZIvLi_AhAu8Xt-NtKfc",
          authDomain: "studysync-f1639.firebaseapp.com",
          projectId: "studysync-f1639",
          storageBucket: "studysync-f1639.appspot.com",
          messagingSenderId: "451077567042",
          appId: "1:451077567042:web:a3b3dd9d922077447b73db",
        ),
      );

      _isInitialized = true;
      print("✅ Firebase initialized successfully");
      return true;
    } catch (e) {
      print("❌ Firebase initialization error: $e");

      if (_initAttempts < maxInitAttempts) {
        // Exponential backoff for retries
        final delay = Duration(
          milliseconds: 500 * (_initAttempts * _initAttempts),
        );
        await Future.delayed(delay);
        return await initializeFirebase(); // Added await here
      }

      return false;
    }
  }

  /// Test Firebase connectivity by multiple methods to ensure more reliable detection
  static Future<bool> testConnectivity({Duration? timeout}) async {
    timeout ??= const Duration(seconds: 3);

    try {
      // First, try Firebase Auth to see if it's responsive
      try {
        final authStream = FirebaseAuth.instance.authStateChanges();
        await authStream.first.timeout(timeout);
        print("✅ Firebase Auth connectivity test successful");
        return true;
      } catch (e) {
        print("⚠️ Firebase Auth connectivity test failed: $e");
        // Continue to next test method
      }

      // Then try Firestore as a backup check
      try {
        final firestoreQuery = FirebaseFirestore.instance
            .collection('users')
            .limit(1);
        await firestoreQuery.get().timeout(timeout);
        print("✅ Firebase Firestore connectivity test successful");
        return true;
      } catch (e) {
        print("⚠️ Firebase Firestore connectivity test failed: $e");
      }

      // If we get here, both test methods failed
      return false;
    } catch (e) {
      print("❌ Firebase connectivity test completely failed: $e");
      return false;
    }
  }

  /// Complete check for Firebase - both initialization and connectivity
  static Future<bool> checkFirebaseConnection() async {
    final isInitialized = await initializeFirebase();
    if (!isInitialized) return false;

    // If the app has just been initialized, give Firebase a moment to connect
    await Future.delayed(const Duration(milliseconds: 500));

    // Only test connectivity if initialization was successful
    return await testConnectivity();
  }

  /// Make a simple "ping" request to test if Firebase is responding properly
  static Future<bool> pingFirebase() async {
    try {
      // A simpler approach to test Firebase is initialized
      if (Firebase.apps.isEmpty) {
        return false;
      }

      // Get the default app
      final FirebaseApp app = Firebase.app();
      // Access app options to verify it's properly set up
      final options = app.options;
      // Just accessing a property to verify it's valid
      final projectId = options.projectId;

      return projectId.isNotEmpty;
    } catch (e) {
      print("❌ Firebase ping failed: $e");
      return false;
    }
  }
}
