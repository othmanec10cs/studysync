import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MatchingService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Find potential study partners who share courses with the current user
  Future<List<Map<String, dynamic>>> findPotentialMatches(
    List<String> currentUserCourses,
  ) async {
    try {
      print("MatchingService: Finding potential matches");

      // Get current user
      final User? currentUser = _auth.currentUser;
      if (currentUser == null) {
        print("MatchingService: No authenticated user");
        throw Exception('User not authenticated');
      }

      print("MatchingService: Current user ID: ${currentUser.uid}");

      // Get current user's courses
      final userDoc =
          await _firestore.collection('users').doc(currentUser.uid).get();

      if (!userDoc.exists || userDoc.data() == null) {
        print("MatchingService: User document not found");
        throw Exception('User data not found');
      }

      final userData = userDoc.data()!;
      final List<String> userCourses = List<String>.from(
        userData['courses'] ?? [],
      );

      print("MatchingService: User courses: $userCourses");

      if (userCourses.isEmpty) {
        print("MatchingService: User has no courses");
        return [];
      }

      // Query for users who share at least one course with the current user
      print("MatchingService: Querying for users with courses: $userCourses");
      final QuerySnapshot usersSnapshot =
          await _firestore
              .collection('users')
              .where('courses', arrayContainsAny: userCourses)
              .get();

      print(
        "MatchingService: Found ${usersSnapshot.docs.length} potential matches",
      );

      List<Map<String, dynamic>> matchedUsers = [];

      for (var doc in usersSnapshot.docs) {
        // Skip the current user
        if (doc.id == currentUser.uid) {
          print("MatchingService: Skipping current user");
          continue;
        }

        print("MatchingService: Processing user ${doc.id}");
        final userData = doc.data() as Map<String, dynamic>;
        final List<String> otherUserCourses = List<String>.from(
          userData['courses'] ?? [],
        );

        print("MatchingService: Other user courses: $otherUserCourses");

        // Find common courses
        List<String> commonCourses =
            userCourses
                .where((course) => otherUserCourses.contains(course))
                .toList();

        print("MatchingService: Common courses: $commonCourses");

        if (commonCourses.isNotEmpty) {
          matchedUsers.add({
            'uid': doc.id,
            'email': userData['email'] ?? 'No email',
            'name': userData['name'] ?? userData['email'] ?? 'Unknown user',
            'commonCourses': commonCourses,
            'matchPercentage':
                (commonCourses.length / userCourses.length * 100).round(),
            'profileImage': userData['profileImage'] ?? '',
          });
          print("MatchingService: Added matched user: ${doc.id}");
        }
      }

      // Sort by number of common courses (highest first)
      matchedUsers.sort((a, b) {
        final List<String> aCommonCourses = List<String>.from(
          a['commonCourses'],
        );
        final List<String> bCommonCourses = List<String>.from(
          b['commonCourses'],
        );
        return bCommonCourses.length.compareTo(aCommonCourses.length);
      });

      print(
        "MatchingService: Final matched users count: ${matchedUsers.length}",
      );
      return matchedUsers;
    } catch (e) {
      print('MatchingService Error finding matches: $e');
      return [];
    }
  }

  // Send a connection request to another user
  Future<bool> sendConnectionRequest(String targetUserId) async {
    try {
      final User? currentUser = _auth.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      // Create connection request
      await _firestore.collection('connectionRequests').add({
        'fromUserId': currentUser.uid,
        'fromUserEmail': currentUser.email,
        'toUserId': targetUserId,
        'status': 'pending',
        'timestamp': FieldValue.serverTimestamp(),
      });

      return true;
    } catch (e) {
      print('Error sending connection request: $e');
      return false;
    }
  }

  // Accept a connection request
  Future<bool> acceptConnectionRequest(String requestId) async {
    try {
      final User? currentUser = _auth.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      // Get request details
      final requestDoc =
          await _firestore
              .collection('connectionRequests')
              .doc(requestId)
              .get();

      if (!requestDoc.exists || requestDoc.data() == null) {
        throw Exception('Request not found');
      }

      final requestData = requestDoc.data()!;

      // Verify this request is for the current user
      if (requestData['toUserId'] != currentUser.uid) {
        throw Exception('Unauthorized action');
      }

      // Update request status
      await _firestore.collection('connectionRequests').doc(requestId).update({
        'status': 'accepted',
      });

      // Create a connection in the connections collection (for both users)
      final fromUserId = requestData['fromUserId'];

      // Create unique connection ID combining both UIDs (alphabetically sorted)
      final connectionId = [fromUserId, currentUser.uid]..sort();
      final connectionDocId = connectionId.join('_');

      await _firestore.collection('connections').doc(connectionDocId).set({
        'users': [fromUserId, currentUser.uid],
        'timestamp': FieldValue.serverTimestamp(),
        'lastInteraction': FieldValue.serverTimestamp(),
      });

      return true;
    } catch (e) {
      print('Error accepting connection request: $e');
      return false;
    }
  }

  // Get all incoming connection requests for the current user
  Future<List<Map<String, dynamic>>> getIncomingRequests() async {
    try {
      final User? currentUser = _auth.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      final querySnapshot =
          await _firestore
              .collection('connectionRequests')
              .where('toUserId', isEqualTo: currentUser.uid)
              .where('status', isEqualTo: 'pending')
              .get();

      return querySnapshot.docs
          .map((doc) => {'id': doc.id, ...doc.data()})
          .toList();
    } catch (e) {
      print('Error getting incoming requests: $e');
      return [];
    }
  }

  // Get all connections for the current user
  Future<List<Map<String, dynamic>>> getUserConnections() async {
    try {
      final User? currentUser = _auth.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      // Query for connections where the current user is in the users array
      final querySnapshot =
          await _firestore
              .collection('connections')
              .where('users', arrayContains: currentUser.uid)
              .get();

      List<Map<String, dynamic>> connections = [];

      for (var doc in querySnapshot.docs) {
        final connectionData = doc.data();
        final List<String> users = List<String>.from(connectionData['users']);

        // Get the other user's ID
        final otherUserId = users.firstWhere((id) => id != currentUser.uid);

        // Get the other user's details
        final otherUserDoc =
            await _firestore.collection('users').doc(otherUserId).get();

        if (otherUserDoc.exists && otherUserDoc.data() != null) {
          final userData = otherUserDoc.data()!;

          connections.add({
            'connectionId': doc.id,
            'userId': otherUserId,
            'email': userData['email'] ?? 'No email',
            'name': userData['name'] ?? userData['email'] ?? 'Unknown user',
            'timestamp': connectionData['timestamp'],
            'lastInteraction': connectionData['lastInteraction'],
            'profileImage': userData['profileImage'] ?? '',
          });
        }
      }

      // Sort by most recent interactions first
      connections.sort((a, b) {
        final Timestamp aTimestamp = a['lastInteraction'] ?? a['timestamp'];
        final Timestamp bTimestamp = b['lastInteraction'] ?? b['timestamp'];
        return bTimestamp.compareTo(aTimestamp);
      });

      return connections;
    } catch (e) {
      print('Error getting user connections: $e');
      return [];
    }
  }
}
