import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Get authentication state stream
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Login with retry capability
  Future<User?> login(
    String email,
    String password, {
    int retryCount = 0,
  }) async {
    try {
      print(
        "AuthService: Attempting login with email: $email (attempt ${retryCount + 1})",
      );

      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Update last login timestamp in Firestore
      if (result.user != null) {
        print("AuthService: Login successful, updating last login timestamp");
        await _firestore
            .collection('users')
            .doc(result.user!.uid)
            .update({'lastLogin': FieldValue.serverTimestamp()})
            .catchError((e) {
              // Non-critical operation, just log the error
              print("AuthService: Could not update last login: $e");
            });
      }

      return result.user;
    } on FirebaseAuthException catch (e) {
      print("AuthService: Login error: ${e.code} - ${e.message}");
      // Retry on network errors
      if ((e.code == 'network-request-failed' ||
              e.message?.contains('network') == true) &&
          retryCount < 2) {
        print("AuthService: Network error detected, retrying...");
        await Future.delayed(Duration(milliseconds: 800 * (retryCount + 1)));
        return login(email, password, retryCount: retryCount + 1);
      }
      // Rethrow to allow specific error handling in UI
      rethrow;
    } catch (e) {
      print("AuthService: Unexpected login error: $e");
      throw Exception('Login failed: $e');
    }
  }

  // Register with retry capability
  Future<User?> register(
    String email,
    String password, {
    int retryCount = 0,
  }) async {
    try {
      print(
        "AuthService: Attempting registration with email: $email (attempt ${retryCount + 1})",
      );

      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Initialize the user document in Firestore
      if (result.user != null) {
        print("AuthService: Registration successful, creating user document");
        await _firestore.collection('users').doc(result.user!.uid).set({
          'email': email,
          'createdAt': FieldValue.serverTimestamp(),
          'lastLogin': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }

      return result.user;
    } on FirebaseAuthException catch (e) {
      print("AuthService: Registration error: ${e.code} - ${e.message}");
      // Retry on network errors
      if ((e.code == 'network-request-failed' ||
              e.message?.contains('network') == true) &&
          retryCount < 2) {
        print("AuthService: Network error detected, retrying...");
        await Future.delayed(Duration(milliseconds: 800 * (retryCount + 1)));
        return register(email, password, retryCount: retryCount + 1);
      }
      // Rethrow to allow specific error handling in UI
      rethrow;
    } catch (e) {
      print("AuthService: Unexpected registration error: $e");
      throw Exception('Registration failed: $e');
    }
  }

  // Reset password with retry capability
  Future<void> resetPassword(String email, {int retryCount = 0}) async {
    try {
      print(
        "AuthService: Sending password reset email to: $email (attempt ${retryCount + 1})",
      );

      await _auth.sendPasswordResetEmail(email: email);
    } on FirebaseAuthException catch (e) {
      print("AuthService: Reset password error: ${e.code} - ${e.message}");
      // Retry on network errors
      if ((e.code == 'network-request-failed' ||
              e.message?.contains('network') == true) &&
          retryCount < 2) {
        print("AuthService: Network error detected, retrying...");
        await Future.delayed(Duration(milliseconds: 800 * (retryCount + 1)));
        return resetPassword(email, retryCount: retryCount + 1);
      }
      rethrow;
    } catch (e) {
      print("AuthService: Unexpected reset password error: $e");
      throw Exception('Password reset failed: $e');
    }
  }

  // Logout
  Future<void> logout() async {
    try {
      print("AuthService: Signing out user");
      await _auth.signOut();
    } catch (e) {
      print("AuthService: Logout error: $e");
      throw Exception('Logout failed: $e');
    }
  }

  // Check if user is logged in
  User? getCurrentUser() {
    return _auth.currentUser;
  }

  // Update user profile
  Future<void> updateUserProfile({
    String? displayName,
    String? photoURL,
  }) async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        if (displayName != null) {
          await user.updateDisplayName(displayName);
        }
        if (photoURL != null) {
          await user.updatePhotoURL(photoURL);
        }
      }
    } catch (e) {
      print("AuthService: Update profile error: $e");
      throw Exception('Profile update failed: $e');
    }
  }
}
