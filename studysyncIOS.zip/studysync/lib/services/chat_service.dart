import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ChatService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String getChatId(String otherUserId) {
    final currentUserId = _auth.currentUser?.uid;
    if (currentUserId == null) {
      throw Exception('User not authenticated');
    }

    final chatUsers = [currentUserId, otherUserId]..sort();
    return chatUsers.join('_');
  }

  Future<bool> sendMessage(String receiverId, String message) async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) throw Exception('User not authenticated');

      final chatId = getChatId(receiverId);
      final timestamp = FieldValue.serverTimestamp();

      await _firestore.collection('chats').doc(chatId).collection('messages').add({
        'senderId': currentUser.uid,
        'senderEmail': currentUser.email,
        'receiverId': receiverId,
        'message': message,
        'timestamp': timestamp,
        'read': false,
      });

      await _firestore.collection('chats').doc(chatId).set({
        'users': [currentUser.uid, receiverId],
        'latestMessage': message,
        'latestMessageTimestamp': timestamp,
        'latestMessageSenderId': currentUser.uid,
      }, SetOptions(merge: true));

      final connectionId = [currentUser.uid, receiverId]..sort();
      final connectionDocId = connectionId.join('_');

      await _firestore.collection('connections').doc(connectionDocId).update({
        'lastInteraction': timestamp,
      });

      return true;
    } catch (e) {
      print('Error sending message: $e');
      return false;
    }
  }

  Future<void> markMessagesAsRead(String chatId, String senderId) async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) throw Exception('User not authenticated');

      final querySnapshot = await _firestore
          .collection('chats')
          .doc(chatId)
          .collection('messages')
          .where('senderId', isEqualTo: senderId)
          .where('read', isEqualTo: false)
          .get();

      final batch = _firestore.batch();
      for (var doc in querySnapshot.docs) {
        batch.update(doc.reference, {'read': true});
      }

      await batch.commit();
    } catch (e) {
      print('Error marking messages as read: $e');
    }
  }

  Stream<QuerySnapshot> getMessages(String otherUserId) {
    final chatId = getChatId(otherUserId);
    return _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .orderBy('timestamp', descending: false)
        .snapshots();
  }

  Stream<QuerySnapshot> getUserChats() {
    final currentUser = _auth.currentUser;
    if (currentUser == null) throw Exception('User not authenticated');

    return _firestore
        .collection('chats')
        .where('users', arrayContains: currentUser.uid)
        .orderBy('latestMessageTimestamp', descending: true)
        .snapshots();
  }

  Future<int> getUnreadCount(String chatId, String senderId) async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) throw Exception('User not authenticated');

      final querySnapshot = await _firestore
          .collection('chats')
          .doc(chatId)
          .collection('messages')
          .where('senderId', isEqualTo: senderId)
          .where('read', isEqualTo: false)
          .count()
          .get();

      return querySnapshot.count ?? 0; 
    } catch (e) {
      print('Error getting unread count: $e');
      return 0;
    }
  }
}

