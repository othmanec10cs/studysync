import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../screens/matches_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<String> userCourses = [];
  bool isLoading = true;
  bool hasError = false;
  String errorMessage = "";
  Map<String, dynamic>? userData;

  @override
  void initState() {
    super.initState();
    fetchUserData();
  }

  Future<void> fetchUserData() async {
    try {
      setState(() {
        isLoading = true;
        hasError = false;
      });

      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        if (mounted) {
          Navigator.of(context).pushReplacementNamed('/login');
        }
        return;
      }

      await user.reload();

      DocumentSnapshot doc =
          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .get();

      if (!doc.exists) {
        await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
          'email': user.email,
          'createdAt': FieldValue.serverTimestamp(),
        });

        if (mounted) {
          Navigator.of(context).pushReplacementNamed('/course_selection');
        }
        return;
      }

      final data = doc.data() as Map<String, dynamic>?;

      if (data == null ||
          !data.containsKey('courses') ||
          data['courses'] == null ||
          (data['courses'] as List).isEmpty) {
        if (mounted) {
          Navigator.of(context).pushReplacementNamed('/course_selection');
        }
        return;
      }

      if (mounted) {
        setState(() {
          userData = data;
          userCourses = List<String>.from(data['courses'] ?? []);
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          isLoading = false;
          hasError = true;
          errorMessage = "Could not load your data. Try again later.";
        });
      }
    }
  }

  void handleEditCourses() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      Navigator.of(context).pushReplacementNamed('/login');
      return;
    }

    Navigator.of(context).pushNamed('/course_selection').then((_) {
      fetchUserData();
    });
  }

  Future<bool> signOut() async {
    try {
      final shouldLogout = await showDialog<bool>(
        context: context,
        builder:
            (context) => AlertDialog(
              title: const Text('Log Out'),
              content: const Text('Are you sure you want to log out?'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Cancel'),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: const Text('Log Out'),
                ),
              ],
            ),
      );

      if (shouldLogout == true) {
        await FirebaseAuth.instance.signOut();
        if (!mounted) return false;
        Navigator.of(
          context,
        ).pushNamedAndRemoveUntil('/login', (route) => false);
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  void navigateToProfileScreen() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      Navigator.of(context).pushReplacementNamed('/login');
      return;
    }
    Navigator.of(context).pushNamed('/profile');
  }

  void showStudyPartners(String course) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      Navigator.of(context).pushReplacementNamed('/login');
      return;
    }

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => MatchesScreen(currentUserCourses: userCourses),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (FirebaseAuth.instance.currentUser == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).pushReplacementNamed('/login');
      });
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final userEmail = FirebaseAuth.instance.currentUser?.email ?? "User";
    final userName = userData?['name'] ?? userEmail.split('@')[0];

    return WillPopScope(
      onWillPop: () async => await signOut(),
      child: Scaffold(
        backgroundColor: const Color(0xFFF4F0F8),
        appBar: AppBar(
          title: const Text("StudySync Dashboard"),
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
              onPressed:
                  () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder:
                          (_) => MatchesScreen(currentUserCourses: userCourses),
                    ),
                  ),
              icon: const Icon(Icons.people),
              tooltip: 'Study Partners',
            ),
            IconButton(
              onPressed: navigateToProfileScreen,
              icon: const Icon(Icons.person),
              tooltip: 'Profile',
            ),
            IconButton(
              onPressed: signOut,
              icon: const Icon(Icons.logout),
              tooltip: 'Log Out',
            ),
          ],
        ),
        body:
            isLoading
                ? const Center(child: CircularProgressIndicator())
                : hasError
                ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.error_outline,
                        size: 48,
                        color: Colors.red,
                      ),
                      const SizedBox(height: 16),
                      Text(errorMessage),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: fetchUserData,
                        child: const Text("Try Again"),
                      ),
                    ],
                  ),
                )
                : Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Card(
                        color: Colors.deepPurple.shade50,
                        elevation: 2,
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  CircleAvatar(
                                    backgroundColor: Colors.deepPurple,
                                    child: Text(
                                      userName.isEmpty
                                          ? "U"
                                          : userName
                                              .substring(0, 1)
                                              .toUpperCase(),
                                      style: const TextStyle(
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      "Welcome, $userName",
                                      style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                "You're enrolled in ${userCourses.length} courses",
                                style: TextStyle(color: Colors.grey.shade700),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Your Courses",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Chip(
                            backgroundColor: Colors.deepPurple,
                            label: Text(
                              "Spring 2025",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child:
                            userCourses.isEmpty
                                ? Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Icon(
                                        Icons.book_outlined,
                                        size: 48,
                                        color: Colors.grey,
                                      ),
                                      const SizedBox(height: 16),
                                      const Text(
                                        "No courses selected yet",
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.grey,
                                        ),
                                      ),
                                      const SizedBox(height: 16),
                                      ElevatedButton(
                                        onPressed: handleEditCourses,
                                        child: const Text("Add Courses"),
                                      ),
                                    ],
                                  ),
                                )
                                : ListView.builder(
                                  itemCount: userCourses.length,
                                  itemBuilder: (context, index) {
                                    return Card(
                                      margin: const EdgeInsets.symmetric(
                                        vertical: 6,
                                      ),
                                      child: ListTile(
                                        leading: CircleAvatar(
                                          backgroundColor:
                                              Colors.deepPurple.shade100,
                                          child: Text(
                                            userCourses[index].isEmpty
                                                ? "?"
                                                : userCourses[index].substring(
                                                  0,
                                                  1,
                                                ),
                                            style: const TextStyle(
                                              color: Colors.deepPurple,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                        title: Text(
                                          userCourses[index],
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        subtitle: const Text(
                                          "Find study partners",
                                        ),
                                        trailing: IconButton(
                                          icon: const Icon(
                                            Icons.people_outline,
                                            color: Colors.deepPurple,
                                          ),
                                          onPressed:
                                              () => showStudyPartners(
                                                userCourses[index],
                                              ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                      ),
                    ],
                  ),
                ),
        floatingActionButton:
            userCourses.isNotEmpty
                ? FloatingActionButton.extended(
                  onPressed: handleEditCourses,
                  backgroundColor: Colors.deepPurple,
                  icon: const Icon(Icons.edit, color: Colors.white),
                  label: const Text(
                    "Edit Courses",
                    style: TextStyle(color: Colors.white),
                  ),
                )
                : null,
      ),
    );
  }
}
