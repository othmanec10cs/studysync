import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart' show rootBundle;

import 'dashboard_screen.dart';

class CourseSelectionScreen extends StatefulWidget {
  const CourseSelectionScreen({super.key});

  @override
  State<CourseSelectionScreen> createState() => _CourseSelectionScreenState();
}

class _CourseSelectionScreenState extends State<CourseSelectionScreen> {
  List<Map<String, String>> allCourses = [];
  List<Map<String, String>> filteredCourses = [];
  final Set<String> selectedCourseCodes = {};
  final TextEditingController searchController = TextEditingController();
  bool isLoading = true;
  bool hasError = false;
  String errorMessage = "";

  @override
  void initState() {
    super.initState();

    // Verify authentication first
    if (FirebaseAuth.instance.currentUser == null) {
      // Handle unauthenticated state
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).pushReplacementNamed('/login');
      });
      return;
    }

    loadCourses().then((_) => fetchUserCourses());
  }

  Future<void> loadCourses() async {
    try {
      final String jsonString = await rootBundle.loadString(
        'assets/aui_courses.json',
      );
      final List<dynamic> jsonData = json.decode(jsonString);
      if (mounted) {
        setState(() {
          allCourses =
              jsonData
                  .map(
                    (course) => {
                      'Course Code': course['Course Code']?.toString() ?? '',
                      'Course Name': course['Course Name']?.toString() ?? '',
                    },
                  )
                  .toList();
          filteredCourses = List.from(allCourses);
        });
      }
    } catch (e) {
      print('Error loading courses: $e');
      if (mounted) {
        setState(() {
          hasError = true;
          errorMessage = "Failed to load course list: $e";
        });
      }
    }
  }

  Future<void> fetchUserCourses() async {
    try {
      // Verify user is authenticated
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        print('User not authenticated, redirecting to login');
        if (mounted) {
          Navigator.of(context).pushReplacementNamed('/login');
        }
        return;
      }

      // Ensure fresh auth token
      await user.reload();

      try {
        final doc =
            await FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .get();
        final data = doc.data();
        final courses = List<String>.from(data?['courses'] ?? []);
        if (mounted) {
          setState(() {
            selectedCourseCodes.addAll(courses);
            isLoading = false;
          });
        }
      } catch (e) {
        print('Error fetching user courses: $e');
        // Check if it's a permissions error
        if (e.toString().contains('permission-denied')) {
          if (mounted) {
            setState(() {
              isLoading = false;
              hasError = true;
              errorMessage =
                  "Permission denied when accessing your data. Please check your Firebase security rules.";
            });
          }
        } else {
          if (mounted) {
            setState(() {
              isLoading = false;
              hasError = true;
              errorMessage = "Failed to load your courses: $e";
            });
          }
        }
      }
    } catch (e) {
      print('General error: $e');
      if (mounted) {
        setState(() {
          isLoading = false;
          hasError = true;
          errorMessage = "An error occurred: $e";
        });
      }
    }
  }

  void filterCourses(String query) {
    setState(() {
      filteredCourses =
          allCourses.where((course) {
            final code = course['Course Code']!.toLowerCase();
            final name = course['Course Name']!.toLowerCase();
            return code.contains(query.toLowerCase()) ||
                name.contains(query.toLowerCase());
          }).toList();
    });
  }

  Future<void> saveCoursesToFirestore() async {
    setState(() {
      isLoading = true;
    });

    // Check authentication before saving
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      // User not authenticated, redirect to login
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please login to save courses.'),
            backgroundColor: Colors.red,
          ),
        );

        setState(() {
          isLoading = false;
        });

        Navigator.of(context).pushReplacementNamed('/login');
      }
      return;
    }

    // Ensure fresh auth token
    await user.reload();

    if (selectedCourseCodes.isNotEmpty) {
      try {
        await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
          'courses': selectedCourseCodes.toList(),
          'email': user.email,
          'lastUpdated': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));

        if (!mounted) return;

        // Success message
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Courses saved successfully!'),
            backgroundColor: Colors.green,
          ),
        );

        // Navigate to dashboard
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const DashboardScreen()),
        );
      } catch (e) {
        if (!mounted) return;

        // Check if it's a permissions error
        if (e.toString().contains('permission-denied')) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Permission denied. Please check your Firebase security rules.',
              ),
              backgroundColor: Colors.red,
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error saving courses: $e'),
              backgroundColor: Colors.red,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }
      }
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select at least one course.'),
          backgroundColor: Colors.orange,
        ),
      );
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Check authentication in build method as well
    if (FirebaseAuth.instance.currentUser == null) {
      // Redirect to login if not authenticated
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).pushReplacementNamed('/login');
      });
      // Return loading indicator while redirecting
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return WillPopScope(
      onWillPop: () async {
        // If back button is pressed, show dialog to confirm logout
        final shouldLogout = await showDialog<bool>(
          context: context,
          builder:
              (context) => AlertDialog(
                title: const Text('Log out?'),
                content: const Text(
                  'You need to select courses to continue. Do you want to log out instead?',
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: const Text('Cancel'),
                  ),
                  TextButton(
                    onPressed: () async {
                      await FirebaseAuth.instance.signOut();
                      if (!mounted) return;
                      Navigator.of(context).pop(true);
                    },
                    child: const Text('Log Out'),
                  ),
                ],
              ),
        );

        return shouldLogout ?? false;
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFF4F0F8),
        appBar: AppBar(
          title: const Text("Select Your Courses"),
          automaticallyImplyLeading: false,
        ),
        body:
            isLoading
                ? const Center(child: CircularProgressIndicator())
                : hasError
                ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.error_outline,
                        size: 48,
                        color: Colors.red,
                      ),
                      const SizedBox(height: 16),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 32),
                        child: Text(errorMessage, textAlign: TextAlign.center),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            isLoading = true;
                            hasError = false;
                          });
                          fetchUserCourses();
                        },
                        child: const Text("Try Again"),
                      ),
                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: () async {
                          await FirebaseAuth.instance.signOut();
                          if (!mounted) return;
                          Navigator.of(context).pushReplacementNamed('/login');
                        },
                        child: const Text("Log Out and Try Again"),
                      ),
                    ],
                  ),
                )
                : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: TextField(
                        controller: searchController,
                        decoration: InputDecoration(
                          hintText: 'Search courses...',
                          prefixIcon: const Icon(Icons.search),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: const BorderSide(
                              color: Colors.deepPurple,
                            ),
                          ),
                        ),
                        onChanged: filterCourses,
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: filteredCourses.length,
                        itemBuilder: (context, index) {
                          final course = filteredCourses[index];
                          final code = course['Course Code']!;
                          final name = course['Course Name']!;
                          final isSelected = selectedCourseCodes.contains(code);
                          return Card(
                            margin: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 4,
                            ),
                            child: CheckboxListTile(
                              title: Text(
                                code,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              subtitle: Text(name),
                              value: isSelected,
                              activeColor: Colors.deepPurple,
                              onChanged: (bool? selected) {
                                setState(() {
                                  if (selected == true) {
                                    selectedCourseCodes.add(code);
                                  } else {
                                    selectedCourseCodes.remove(code);
                                  }
                                });
                              },
                            ),
                          );
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        '${selectedCourseCodes.length} courses selected',
                        style: TextStyle(
                          color:
                              selectedCourseCodes.isEmpty
                                  ? Colors.red
                                  : Colors.green,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed:
              selectedCourseCodes.isEmpty || isLoading
                  ? null
                  : saveCoursesToFirestore,
          backgroundColor:
              selectedCourseCodes.isEmpty || isLoading
                  ? Colors.grey
                  : Colors.deepPurple,
          icon:
              isLoading
                  ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2.0,
                    ),
                  )
                  : const Icon(Icons.arrow_forward),
          label: Text(isLoading ? "Saving..." : "Save & Continue"),
        ),
      ),
    );
  }
}
