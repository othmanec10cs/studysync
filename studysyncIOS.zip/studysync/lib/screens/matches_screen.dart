import 'package:flutter/material.dart';
import '../services/matching_service.dart';
import 'chat_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MatchesScreen extends StatefulWidget {
  final List<String> currentUserCourses;

  const MatchesScreen({super.key, required this.currentUserCourses});

  @override
  State<MatchesScreen> createState() => _MatchesScreenState();
}

class _MatchesScreenState extends State<MatchesScreen>
    with SingleTickerProviderStateMixin {
  final MatchingService _matchingService = MatchingService();
  late TabController _tabController;
  bool _isLoading = true;
  bool _isError = false;
  List<Map<String, dynamic>> _potentialMatches = [];
  List<Map<String, dynamic>> _incomingRequests = [];
  List<Map<String, dynamic>> _connections = [];
  String? _errorMessage;
  bool _hasPermissionError = false;

  @override
  void initState() {
    super.initState();

    _tabController = TabController(length: 3, vsync: this);

    // Wait for auth to stabilize before proceeding
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await _ensureAuthenticatedAndLoadData();
    });
  }

  Future<void> _ensureAuthenticatedAndLoadData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
      return;
    }
    await user.reload();
    if (FirebaseAuth.instance.currentUser == null) {
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
      return;
    }
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
      _isError = false;
      _errorMessage = null;
      _hasPermissionError = false;
    });

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        if (mounted) {
          Navigator.of(
            context,
          ).pushNamedAndRemoveUntil('/login', (route) => false);
        }
        return;
      }

      await user.reload();

      print("MatchesScreen: Loading data");
      try {
        final matches = await _matchingService.findPotentialMatches(
          widget.currentUserCourses,
        );
        print("MatchesScreen: Found \${matches.length} potential matches");

        final requests = await _matchingService.getIncomingRequests();
        print("MatchesScreen: Found \${requests.length} incoming requests");

        final connections = await _matchingService.getUserConnections();
        print("MatchesScreen: Found \${connections.length} connections");

        if (mounted) {
          setState(() {
            _potentialMatches = matches;
            _incomingRequests = requests;
            _connections = connections;
            _isLoading = false;
          });
        }
      } catch (e) {
        print("MatchesScreen: Error loading data: \$e");

        if (e.toString().contains('permission-denied')) {
          if (mounted) {
            setState(() {
              _isError = true;
              _hasPermissionError = true;
              _errorMessage =
                  'Permission denied when accessing data. Please check your Firebase security rules.';
              _isLoading = false;
            });
          }
        } else {
          if (mounted) {
            setState(() {
              _isError = true;
              _errorMessage = 'Error loading data: \$e';
              _isLoading = false;
            });
          }
        }
      }
    } catch (e) {
      print("MatchesScreen: General error: \$e");
      if (mounted) {
        setState(() {
          _isError = true;
          _errorMessage = 'An unexpected error occurred: \$e';
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _sendConnectionRequest(String userId) async {
    // Check authentication before sending request
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please login to send connection requests'),
          backgroundColor: Colors.red,
        ),
      );
      Navigator.of(context).pushReplacementNamed('/login');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final success = await _matchingService.sendConnectionRequest(userId);

      if (success) {
        // Update UI to reflect the request was sent
        setState(() {
          _potentialMatches =
              _potentialMatches.map((match) {
                if (match['uid'] == userId) {
                  return {...match, 'requestSent': true};
                }
                return match;
              }).toList();
          _isLoading = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Connection request sent!'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        setState(() {
          _isLoading = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to send request. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });

      // Check for permission errors
      if (e.toString().contains('permission-denied')) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Permission denied. Check your Firebase security rules.',
            ),
            backgroundColor: Colors.red,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _acceptRequest(String requestId) async {
    // Check authentication before accepting request
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please login to accept connection requests'),
          backgroundColor: Colors.red,
        ),
      );
      Navigator.of(context).pushReplacementNamed('/login');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final success = await _matchingService.acceptConnectionRequest(requestId);

      if (success) {
        // Refresh data to show updated connections
        _loadData();

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Connection accepted!'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        setState(() {
          _isLoading = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to accept request. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });

      // Check for permission errors
      if (e.toString().contains('permission-denied')) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Permission denied. Check your Firebase security rules.',
            ),
            backgroundColor: Colors.red,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Check authentication in build method
    if (FirebaseAuth.instance.currentUser == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).pushReplacementNamed('/login');
      });
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Study Partners'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Find Partners'),
            Tab(text: 'Requests'),
            Tab(text: 'Connections'),
          ],
        ),
      ),
      body:
          _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _isError
              ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _hasPermissionError
                          ? Icons.security
                          : Icons.error_outline,
                      size: 48,
                      color: _hasPermissionError ? Colors.orange : Colors.red,
                    ),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Text(
                        _errorMessage ?? 'An error occurred',
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _loadData,
                      child: const Text('Try Again'),
                    ),
                    if (_hasPermissionError) ...[
                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: () async {
                          await FirebaseAuth.instance.signOut();
                          if (!mounted) return;
                          Navigator.of(context).pushReplacementNamed('/login');
                        },
                        child: const Text('Log Out and Try Again'),
                      ),
                    ],
                  ],
                ),
              )
              : RefreshIndicator(
                onRefresh: _loadData,
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildPotentialMatchesTab(),
                    _buildIncomingRequestsTab(),
                    _buildConnectionsTab(),
                  ],
                ),
              ),
    );
  }

  Widget _buildPotentialMatchesTab() {
    if (_potentialMatches.isEmpty) {
      return _buildEmptyState(
        icon: Icons.people_outline,
        message: 'No potential study partners found',
        description: 'Try adding more courses to find more study partners',
      );
    }

    return ListView.builder(
      itemCount: _potentialMatches.length,
      itemBuilder: (context, index) {
        final match = _potentialMatches[index];
        final commonCourses = List<String>.from(match['commonCourses']);
        final bool requestSent = match['requestSent'] ?? false;

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.deepPurple.shade100,
                      radius: 24,
                      child: Text(
                        match['name'].toString().substring(0, 1).toUpperCase(),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.deepPurple,
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            match['name'] ?? 'Study Partner',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            match['email'] ?? '',
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.deepPurple.shade100,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${match['matchPercentage']}% match',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.deepPurple,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const Text(
                  'Courses in common:',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children:
                      commonCourses
                          .map(
                            (course) => Chip(
                              backgroundColor: Colors.deepPurple.shade50,
                              label: Text(course),
                            ),
                          )
                          .toList(),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed:
                        requestSent
                            ? null
                            : () => _sendConnectionRequest(match['uid']),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurple,
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: Colors.grey.shade300,
                    ),
                    child: Text(requestSent ? 'Request Sent' : 'Connect'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildIncomingRequestsTab() {
    if (_incomingRequests.isEmpty) {
      return _buildEmptyState(
        icon: Icons.inbox_outlined,
        message: 'No pending requests',
        description:
            'When someone wants to connect with you, it will appear here',
      );
    }

    return ListView.builder(
      itemCount: _incomingRequests.length,
      itemBuilder: (context, index) {
        final request = _incomingRequests[index];

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.deepPurple.shade100,
              child: Text(
                request['fromUserEmail']
                    .toString()
                    .substring(0, 1)
                    .toUpperCase(),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.deepPurple,
                ),
              ),
            ),
            title: Text(request['fromUserEmail'] ?? 'Unknown User'),
            subtitle: Text('Wants to connect with you'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.red),
                  onPressed: () {
                    // TODO: Implement reject functionality
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Request declined')),
                    );
                    _loadData();
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.check, color: Colors.green),
                  onPressed: () => _acceptRequest(request['id']),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildConnectionsTab() {
    if (_connections.isEmpty) {
      return _buildEmptyState(
        icon: Icons.people_alt_outlined,
        message: 'No connections yet',
        description: 'Connect with other students to see them here',
      );
    }

    return ListView.builder(
      itemCount: _connections.length,
      itemBuilder: (context, index) {
        final connection = _connections[index];

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.deepPurple.shade100,
              child: Text(
                connection['name'].toString().substring(0, 1).toUpperCase(),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.deepPurple,
                ),
              ),
            ),
            title: Text(connection['name'] ?? 'Study Partner'),
            subtitle: Text(connection['email'] ?? ''),
            trailing: IconButton(
              icon: const Icon(Icons.message_outlined),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder:
                        (context) => ChatScreen(
                          receiverId: connection['userId'],
                          receiverName: connection['name'] ?? 'Study Partner',
                          receiverEmail: connection['email'] ?? '',
                        ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyState({
    required IconData icon,
    required String message,
    required String description,
  }) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 80, color: Colors.grey.shade400),
            const SizedBox(height: 24),
            Text(
              message,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              description,
              style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
