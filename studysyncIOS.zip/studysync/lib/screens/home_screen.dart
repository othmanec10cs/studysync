import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

import 'login_screen.dart';
import 'course_selection_screen.dart';
import 'dashboard_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  String _statusMessage = "Checking your information...";
  bool _hasError = false;
  bool _timedOut = false;
  int _retryAttempt = 0;
  bool _isRetrying = false;
  bool _hasPermissionError = false;

  @override
  void initState() {
    super.initState();

    // Setup animations
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.0, 0.5, curve: Curves.easeIn),
      ),
    );

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<Widget> _resolveNextScreen() async {
    // Use a shorter timeout
    return Future.any([
      _actualNavigationWithRetry(),
      Future.delayed(const Duration(seconds: 6), () {
        setState(() {
          _timedOut = true;
          _hasError = true;
          _statusMessage = "Loading took too long. Please try again.";
        });
        print("⏱️ Navigation timed out after 6 seconds");
        return _buildErrorScreen(
          "Connection timed out. Please check your Firebase permissions and internet connection.",
        );
      }),
    ]);
  }

  Future<Widget> _actualNavigationWithRetry() async {
    _retryAttempt++;
    if (_retryAttempt > 1) {
      print("🔄 Retry attempt #${_retryAttempt - 1}");
      if (mounted) {
        setState(() {
          _statusMessage = "Retrying... (${_retryAttempt - 1})";
          _isRetrying = true;
        });
      }
      // Add a small delay between retries
      await Future.delayed(Duration(milliseconds: 800));
    }

    try {
      return await _actualNavigation();
    } catch (e) {
      print("❌ Error during navigation attempt: $e");

      // Check if it's a permissions error
      if (e.toString().contains('permission-denied')) {
        if (mounted) {
          setState(() {
            _hasPermissionError = true;
            _hasError = true;
            _statusMessage =
                "Firebase permissions error. Please check your security rules.";
          });
        }
        return _buildPermissionErrorScreen();
      }

      // For other errors, retry if needed
      if (_retryAttempt < 3) {
        return _actualNavigationWithRetry();
      } else {
        throw Exception("Navigation failed after multiple retries: $e");
      }
    } finally {
      if (mounted) {
        setState(() {
          _isRetrying = false;
        });
      }
    }
  }

  Future<Widget> _actualNavigation() async {
    try {
      // First check if user is authenticated
      final user = FirebaseAuth.instance.currentUser;

      if (user == null) {
        if (mounted) {
          setState(() {
            _statusMessage = "You need to login...";
          });
        }
        print("🧪 User not logged in");
        await Future.delayed(const Duration(milliseconds: 500));
        return const LoginScreen();
      }

      // User is authenticated
      if (mounted) {
        setState(() {
          _statusMessage = "Checking your courses...";
        });
      }

      // Try to get user document
      try {
        final doc =
            await FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .get();

        // If document doesn't exist, create it and go to course selection
        if (!doc.exists || doc.data() == null) {
          // Create user document if it doesn't exist
          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .set({
                'email': user.email,
                'createdAt': FieldValue.serverTimestamp(),
              });

          print("🧪 User document created, going to Course Selection");
          return const CourseSelectionScreen();
        }

        // Document exists, check for courses
        final data = doc.data();
        print("🧪 Firestore document data: $data");
        final courses = data?['courses'];
        print("🧪 Courses fetched: $courses");

        if (courses != null && courses.isNotEmpty) {
          if (mounted) {
            setState(() {
              _statusMessage = "Loading your dashboard...";
            });
          }
          print("✅ User has selected courses. Going to Dashboard.");
          await Future.delayed(const Duration(milliseconds: 300));
          return const DashboardScreen();
        } else {
          if (mounted) {
            setState(() {
              _statusMessage = "You need to select courses...";
            });
          }
          print(
            "🟡 User logged in, but no courses. Going to Course Selection.",
          );
          await Future.delayed(const Duration(milliseconds: 300));
          return const CourseSelectionScreen();
        }
      } catch (e) {
        print("❌ Error fetching user document: $e");

        // If it's a permissions error, handle specifically
        if (e.toString().contains('permission-denied')) {
          setState(() {
            _hasPermissionError = true;
          });
          throw Exception("Firebase permissions error: $e");
        }

        throw e; // rethrow other errors
      }
    } catch (e) {
      print("❌ Error during navigation: $e");
      throw e; // Rethrow to be handled by caller
    }
  }

  Widget _buildPermissionErrorScreen() {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F0F8),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.security, size: 64, color: Colors.orange),
            const SizedBox(height: 24),
            const Text(
              "Firebase Permissions Issue",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                "Your app doesn't have permission to access the Firestore database. "
                "Please check your Firebase security rules in the Firebase Console.",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade700),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () async {
                await FirebaseAuth.instance.signOut();
                if (!mounted) return;
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Colors.deepPurple,
                padding: const EdgeInsets.symmetric(
                  horizontal: 32,
                  vertical: 12,
                ),
              ),
              child: const Text("Log Out and Try Again"),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorScreen(String error) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F0F8),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              _hasPermissionError ? Icons.security : Icons.error_outline,
              size: 64,
              color: _hasPermissionError ? Colors.orange : Colors.red,
            ),
            const SizedBox(height: 24),
            const Text(
              "Oops! Something went wrong",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                error,
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade700),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed:
                  _isRetrying
                      ? null
                      : () {
                        setState(() {
                          _isRetrying = true;
                          _timedOut = false;
                          _hasError = false;
                          _retryAttempt = 0;
                          _hasPermissionError = false;
                          _statusMessage = "Retrying connection...";
                        });

                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (_) => const HomeScreen()),
                        );
                      },
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Colors.deepPurple,
                padding: const EdgeInsets.symmetric(
                  horizontal: 32,
                  vertical: 12,
                ),
              ),
              child:
                  _isRetrying
                      ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2.0,
                        ),
                      )
                      : const Text("Try Again"),
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () async {
                try {
                  await FirebaseAuth.instance.signOut();
                } catch (e) {
                  print("Logout error: $e");
                }
                if (!mounted) return;
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                );
              },
              child: const Text("Log Out Instead"),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Widget>(
      future: _resolveNextScreen(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting && !_timedOut) {
          return _buildLoadingScreen();
        }

        if (snapshot.hasError || !snapshot.hasData) {
          String errorMessage = "Navigation failed";

          if (snapshot.hasError) {
            errorMessage = snapshot.error.toString();
            // Check if it's a permissions error
            if (errorMessage.contains('permission-denied')) {
              return _buildPermissionErrorScreen();
            }
          }

          return _buildErrorScreen(errorMessage);
        }

        return snapshot.data!;
      },
    );
  }

  Widget _buildLoadingScreen() {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F0F8),
      body: Center(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.school, size: 80, color: Colors.deepPurple),
              const SizedBox(height: 24),
              const Text(
                "StudySync",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.deepPurple,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                "Connect & Study Together",
                style: TextStyle(fontSize: 16, color: Colors.black54),
              ),
              const SizedBox(height: 40),
              _hasError
                  ? Icon(
                    _hasPermissionError ? Icons.security : Icons.error_outline,
                    color: _hasPermissionError ? Colors.orange : Colors.red,
                    size: 40,
                  )
                  : _isRetrying
                  ? Column(
                    children: [
                      const SizedBox(
                        width: 40,
                        height: 40,
                        child: CircularProgressIndicator(
                          color: Colors.deepPurple,
                          strokeWidth: 3,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        _statusMessage,
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  )
                  : Column(
                    children: [
                      const SizedBox(
                        width: 40,
                        height: 40,
                        child: CircularProgressIndicator(
                          color: Colors.deepPurple,
                          strokeWidth: 3,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        _statusMessage,
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
              if (_hasError || _timedOut) ...[
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed:
                      _isRetrying
                          ? null
                          : () {
                            setState(() {
                              _isRetrying = true;
                              _timedOut = false;
                              _hasError = false;
                              _retryAttempt = 0;
                              _hasPermissionError = false;
                              _statusMessage = "Retrying connection...";
                            });

                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const HomeScreen(),
                              ),
                            );
                          },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 32,
                      vertical: 12,
                    ),
                  ),
                  child:
                      _isRetrying
                          ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2.0,
                            ),
                          )
                          : const Text("Try Again"),
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (_) => const LoginScreen()),
                    );
                  },
                  child: const Text("Continue to Login"),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
