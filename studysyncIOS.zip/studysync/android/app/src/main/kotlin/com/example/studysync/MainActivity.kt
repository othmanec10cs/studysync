package com.example.studysync

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
